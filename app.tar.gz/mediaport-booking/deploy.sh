#!/usr/bin/env bash
# Установка и запуск МЕДИАПОРТ-брони в тестовом режиме (HTTP, без домена).
# Использование: bash deploy.sh ПАРОЛЬ_АДМИНА ПАРОЛЬ_ВЛАДЕЛЬЦА [URL]
set -e
ADMIN="$1"; OWNER="$2"
PUB="${3:-http://$(hostname -I | awk '{print $1}')}"
if [ -z "$ADMIN" ] || [ -z "$OWNER" ]; then
  echo "Укажите два пароля: bash deploy.sh ПАРОЛЬ_АДМИНА ПАРОЛЬ_ВЛАДЕЛЬЦА"
  exit 1
fi
cd "$(dirname "$0")"
echo "== Устанавливаю Docker (если ещё не стоит) =="
command -v docker >/dev/null 2>&1 || curl -fsSL https://get.docker.com | sh
echo "== Собираю образ =="
docker build -t mediaport .
echo "== Запускаю =="
docker rm -f mediaport >/dev/null 2>&1 || true
docker run -d --name mediaport --restart unless-stopped -p 80:3000 \
  -e ADMIN_PASSWORD="$ADMIN" \
  -e OWNER_PASSWORD="$OWNER" \
  -e SESSION_SECRET="$(openssl rand -hex 32 2>/dev/null || date +%s%N%N)" \
  -e PUBLIC_URL="$PUB" \
  -v mp_data:/data mediaport
command -v ufw >/dev/null 2>&1 && ufw allow 80 >/dev/null 2>&1 || true
sleep 3
echo "========================================"
echo "Готово. Откройте в браузере: $PUB"
echo "Админка: $PUB/admin"
echo "========================================"
docker ps --filter name=mediaport
