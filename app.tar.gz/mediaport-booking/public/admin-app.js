(function(){
'use strict';
const P=window.Pricing;
const {pad,parse,ymd,hr,isWe,hoursWord,rub}=P;
const MON=['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
const MONN=['январь','февраль','март','апрель','май','июнь','июль','август','сентябрь','октябрь','ноябрь','декабрь'];
const WD=['вс','пн','вт','ср','чт','пт','сб'];
const ST={awaiting:'Ждёт оплату',review:'Забронировано, не подтверждено',confirmed:'Забронировано',blocked:'Закрыто',rejected:'Отклонена',cancelled:'Отменена',expired:'Не оплачена вовремя'};
const ACTIVE=['awaiting','review','confirmed','blocked'];
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtDate=s=>{const d=parse(s);return d.getDate()+' '+MON[d.getMonth()]+', '+WD[d.getDay()]};
const span=(start,hours)=>pad(hr(start))+':00–'+pad(hr(start+hours))+':00'+(start+hours>18?' (до утра)':'');
const clock=t=>{const d=new Date(t);return pad(d.getHours())+':'+pad(d.getMinutes())};
const left=ms=>{ms=Math.max(0,ms);const s=Math.floor(ms/1000);return pad(Math.floor(s/3600))+':'+pad(Math.floor(s%3600/60))+':'+pad(s%60)};
const brn=n=>n+' '+(n%10===1&&n%100!==11?'бронь':(n%10>=2&&n%10<=4&&(n%100<10||n%100>=20)?'брони':'броней'));
const digits=s=>String(s||'').replace(/\D/g,'').slice(-10);
function slotTime(date,i){const d=parse(date);d.setHours(6+i,0,0,0);return d.getTime()}

let S=null,bookings=[],feed=[],TG={},todayS='',skew=0,ROLE='admin';
const RO=()=>ROLE==='owner';
const nowMs=()=>Date.now()+skew;
const T=k=>{const d=parse(todayS);d.setDate(d.getDate()+k);return ymd(d)};
const hall=id=>S.halls.find(h=>h.id===id)||{name:id};
const deadline=b=>b.status==='review'?(b.paidAt||0)+S.confirmH*3600000:b.createdAt+S.payMin*60000;
const fmtDeadline=b=>{const d=new Date(deadline(b));return d.getDate()+' '+MON[d.getMonth()]+', '+clock(d)};
const norm=b=>Object.assign(b,{fullPaid:!!b.full_paid,depositState:b.deposit_state||'none',createdAt:b.created_at,paidAt:b.paid_at,overdue:!!b.overdue});

async function api(path,opts){
  const r=await fetch(path,Object.assign({headers:{'content-type':'application/json'},credentials:'same-origin'},opts||{}));
  let j={};try{j=await r.json()}catch(_){}
  if(r.status===401&&!path.endsWith('/login')){showLogin();throw new Error(j.error||'Войдите')}
  if(!r.ok){const e=new Error(j.error||'Ошибка связи');e.status=r.status;throw e}
  return j;
}
async function load(){
  const j=await api('/api/admin/state');
  S=j.settings;bookings=j.bookings.map(norm);feed=j.feed;TG=j.telegram;todayS=j.today;skew=j.now-Date.now();ROLE=j.role||'admin';
  if(!schedDate)schedDate=todayS;
}

/* ---------- состояние интерфейса ---------- */
let view='today',q='',fStatus='active',fHall='',schedDate='',period='month',openId=null,draft=null,moveOpen=false,cancelOpen=false,cq='';
const AM=document.getElementById('adm-main');
const NAV=[['today','Сегодня'],['orders','Брони'],['sched','Расписание'],['clients','Клиенты'],['stats','Статистика'],['settings','Настройки']];
function occ(b){return [b.start-(b.pre||0),b.start+b.hours+(b.post||0)]}
function busyBy(hid,date,i){return bookings.find(b=>b.date===date&&ACTIVE.includes(b.status)&&(b.hall===hid||b.hall==='all'||hid==='all')&&i>=occ(b)[0]&&i<occ(b)[1])}
function busyList(date,excl){return bookings.filter(b=>b.date===date&&ACTIVE.includes(b.status)&&b.id!==excl).map(b=>({hall:b.hall,start:occ(b)[0],end:occ(b)[1]}))}
function badge(n,cls){return n?'<span class="cnt '+(cls||'')+'">'+n+'</span>':''}
function pill(b){if(b.status==='confirmed'&&b.fullPaid)return '<span class="pill paid">Оплачено полностью</span>';return '<span class="pill st-'+b.status+'">'+(b.status==='review'&&b.overdue?'Просрочено подтверждение':ST[b.status])+'</span>'}
const who=b=>b.status==='blocked'?'Закрыто: '+esc(b.reason):esc(b.name);

function renderAdmin(){
  const rev=bookings.filter(b=>b.status==='review');
  document.title=(rev.length?'('+rev.length+') ':'')+'Админка — '+S.studio.name;
  document.body.classList.toggle('ro',RO());
  const rbadge=document.getElementById('role-badge'),sub=document.getElementById('role-sub');
  if(rbadge)rbadge.hidden=!RO();if(sub)sub.textContent=RO()?'Просмотр владельца':'Панель администратора';
  document.getElementById('adm-nav').innerHTML=NAV.map(([k,l])=>'<button role="tab" data-v="'+k+'" aria-selected="'+(view===k)+'">'+l+(k==='today'?badge(rev.length,rev.some(b=>b.overdue)?'bad':''):'')+'</button>').join('');
  AM.innerHTML={today:viewToday,orders:viewOrders,sched:viewSched,clients:viewClients,stats:viewStats,settings:viewSettings}[view]();
  if(view==='orders'){const i=document.getElementById('adm-q');i.addEventListener('input',()=>{q=i.value;document.getElementById('ord-list').innerHTML=ordRows()});document.getElementById('adm-hall').addEventListener('change',e=>{fHall=e.target.value;document.getElementById('ord-list').innerHTML=ordRows()})}
  if(view==='clients'){const i=document.getElementById('cl-q');i.addEventListener('input',()=>{cq=i.value;document.getElementById('cl-list').innerHTML=clientRows()})}
  renderDrawer();
}

/* Сегодня */
function viewToday(){
  const nowD=new Date(nowMs());
  const rev=bookings.filter(b=>b.status==='review').sort((a,b)=>deadline(a)-deadline(b));
  const aw=bookings.filter(b=>b.status==='awaiting');
  const tb=bookings.filter(b=>b.date===T(0)&&ACTIVE.includes(b.status)).sort((a,b)=>a.start-b.start);
  const due=tb.filter(b=>b.status==='confirmed'&&!b.fullPaid);
  const depRet=bookings.filter(b=>b.depositState==='held'&&b.date<T(0));
  const depTake=tb.filter(b=>b.status==='confirmed'&&b.deposit&&b.depositState==='none');
  const tasks=[];
  rev.forEach(b=>tasks.push({u:b.overdue?0:1,h:'<div class="todo'+(b.overdue?' urgent':'')+'"><div><b>'+(b.overdue?'Просрочено: ':'')+'проверить перевод '+rub(b.prepay)+'</b><span>№'+b.id+' · '+esc(b.name)+' · '+esc(hall(b.hall).name)+', '+fmtDate(b.date)+(b.overdue?'':' · до '+clock(deadline(b)))+'</span></div><div class="actions"><button class="btn ok" data-q="confirm" data-id="'+b.id+'">Подтвердить</button><button class="btn" data-open="'+b.id+'">Открыть</button></div></div>'}));
  depTake.forEach(b=>tasks.push({u:2,h:'<div class="todo"><div><b>Взять залог '+rub(b.deposit)+' до начала</b><span>№'+b.id+' · '+esc(b.name)+' · сегодня в '+pad(hr(b.start))+':00</span></div><div class="actions"><button class="btn ok" data-q="depin" data-id="'+b.id+'">Залог получен</button></div></div>'}));
  due.forEach(b=>tasks.push({u:2,h:'<div class="todo"><div><b>Доплата '+rub(b.total-b.prepay)+' на месте</b><span>№'+b.id+' · '+esc(b.name)+' · сегодня в '+pad(hr(b.start))+':00, '+esc(hall(b.hall).name)+'</span></div><div class="actions"><button class="btn ok" data-q="full" data-id="'+b.id+'">Доплата получена</button></div></div>'}));
  depRet.forEach(b=>tasks.push({u:3,h:'<div class="todo"><div><b>Вернуть залог '+rub(b.deposit)+'</b><span>№'+b.id+' · '+esc(b.name)+' · мероприятие '+fmtDate(b.date)+'</span></div><div class="actions"><button class="btn ok" data-q="depout" data-id="'+b.id+'">Залог возвращён</button><button class="btn" data-open="'+b.id+'">Открыть</button></div></div>'}));
  tasks.sort((a,b)=>a.u-b.u);
  const curIdx=(nowD.getHours()-6+24)%24;let nextMarked=false;
  const timeline=tb.length?tb.map(b=>{
    const s=b.start,e=b.start+b.hours;let tag='';
    if(curIdx>=s&&curIdx<e)tag='<span class="now">идёт сейчас</span>';
    else if(s>curIdx&&!nextMarked){nextMarked=true;const mins=Math.round((slotTime(b.date,s)-nowMs())/60000);tag='<span class="next">через '+(mins>=60?Math.floor(mins/60)+' ч '+(mins%60)+' мин':mins+' мин')+'</span>'}
    return '<button class="tl'+(e<=curIdx?' done':'')+'" data-open="'+b.id+'"><span class="tl-time num">'+span(b.start,b.hours)+'</span><span class="tl-main"><b>'+esc(hall(b.hall).name)+'</b> · '+who(b)+(b.status!=='blocked'?'<small>'+b.guests+' чел. · '+esc(b.format)+'</small>':'')+'</span><span class="tl-side">'+tag+pill(b)+'</span></button>'}).join(''):'<div class="empty">Сегодня броней нет.</div>';
  const todayRev=tb.filter(b=>b.status==='confirmed').reduce((s,b)=>s+b.total,0);
  return '<div style="display:grid;gap:14px;min-width:0">'+
    '<div class="kpis">'+
      '<button class="kpi act'+(rev.some(b=>b.overdue)?' bad':rev.length?' warn':'')+'" data-goto="review"><small>Подтвердить оплату</small><b>'+rev.length+'</b><span>'+(rev.length?'на '+rub(rev.reduce((s,b)=>s+b.prepay,0)):'всё проверено')+'</span></button>'+
      '<button class="kpi act" data-goto="awaiting"><small>Ждут перевода</small><b>'+aw.length+'</b><span>ещё не нажали «Я оплатил»</span></button>'+
      '<button class="kpi act'+(due.length?' warn':'')+'" data-goto="unpaid"><small>Доплаты сегодня</small><b>'+rub(due.reduce((s,b)=>s+b.total-b.prepay,0))+'</b><span>'+brn(due.length)+'</span></button>'+
      '<div class="kpi"><small>Сегодня</small><b>'+tb.filter(b=>b.status!=='blocked').length+'</b><span>'+(tb.length?'подтверждено на '+rub(todayRev):'свободный день')+'</span></div>'+
    '</div>'+
    '<div class="desk-grid"><div style="display:grid;gap:14px;min-width:0">'+
    '<div class="sec"><div class="sec-head"><h4>Нужно сделать</h4><span class="note">'+(tasks.length?tasks.length+' задач':'')+'</span></div>'+(tasks.length?tasks.map(t=>t.h).join(''):'<div class="empty">Всё сделано. Новые задачи появятся, когда клиент оплатит бронь или придёт день доплаты.</div>')+'</div>'+
    '<div class="sec"><div class="sec-head"><h4>Расписание на сегодня, '+fmtDate(T(0))+'</h4><button class="btn" data-new>+ Бронь</button></div>'+timeline+'</div>'+
    '</div><aside class="tg" aria-label="Лента событий"><div class="tg-head"><div class="tg-ava">MП</div><div><b>Лента событий</b><br><small class="note">'+(TG.enabled?'уведомления дублируются в Telegram':'Telegram-бот не подключён')+'</small></div></div><div style="display:grid;gap:8px">'+feed.slice(0,12).map(m=>'<div class="msg"><span>'+esc(m.text)+'</span><time class="num">'+new Date(m.t).toLocaleString('ru-RU',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})+'</time></div>').join('')+'</div></aside></div></div>';
}

/* Брони */
const FST=[['active','Активные'],['review','Не подтверждены'],['awaiting','Ждут оплату'],['unpaid','Ждут доплату'],['past','Прошедшие'],['cancel','Отмены'],['blocked','Закрытое время'],['all','Все']];
function matchSt(b,k){
  if(k==='all')return true;
  if(k==='active')return ['awaiting','review','confirmed'].includes(b.status)&&b.date>=T(0);
  if(k==='unpaid')return b.status==='confirmed'&&!b.fullPaid;
  if(k==='past')return b.status==='confirmed'&&b.date<T(0);
  if(k==='cancel')return ['cancelled','rejected','expired'].includes(b.status);
  return b.status===k;
}
function ordRows(){
  const qq=q.trim().toLowerCase(),qd=digits(q);
  let rows=bookings.filter(b=>(qq?true:matchSt(b,fStatus))&&(!fHall||b.hall===fHall)&&(!qq||String(b.id).includes(qq)||(b.name||'').toLowerCase().includes(qq)||(qd.length>=3&&digits(b.phone).includes(qd))));
  const desc=!!qq||['past','cancel','all'].includes(fStatus);
  rows.sort((a,b)=>desc?(b.date.localeCompare(a.date)||b.start-a.start):(a.date.localeCompare(b.date)||a.start-b.start));
  if(!rows.length)return '<div class="empty">Ничего не нашлось. Измените фильтр или поиск.</div>';
  const sum=rows.filter(b=>b.status==='confirmed').reduce((s,b)=>s+b.total,0);
  return '<p class="note">'+(qq?'Поиск по всем броням: ':'')+brn(rows.length)+(sum?' · подтверждено на '+rub(sum):'')+'</p>'+rows.slice(0,100).map(b=>'<button class="orow" data-open="'+b.id+'"><span class="num o-id">№'+b.id+'</span><span class="o-when num">'+fmtDate(b.date)+'<small>'+span(b.start,b.hours)+'</small></span><span class="o-who">'+who(b)+'<small>'+esc(hall(b.hall).name)+(b.status!=='blocked'?' · '+(b.purpose==='event'?'мероприятие':'фото')+' · '+b.guests+' чел.':'')+'</small></span><span class="o-sum num">'+(b.total?rub(b.total):'')+'</span><span class="o-st">'+pill(b)+'</span></button>').join('')+(rows.length>100?'<p class="note">Показаны первые 100. Уточните поиск.</p>':'');
}
function viewOrders(){
  return '<div style="display:grid;gap:12px">'+
    '<div class="toolbar"><input id="adm-q" type="search" placeholder="Поиск: имя, телефон или №" value="'+esc(q)+'"><select id="adm-hall" aria-label="Локация"><option value="">Все локации</option>'+S.halls.map(h=>'<option value="'+h.id+'"'+(fHall===h.id?' selected':'')+'>'+esc(h.name)+'</option>').join('')+'</select><button class="btn ok" data-new>+ Новая бронь</button></div>'+
    '<div class="filters">'+FST.map(([k,l])=>'<button data-fs="'+k+'" aria-pressed="'+(fStatus===k)+'">'+l+'<span class="n num">'+bookings.filter(b=>matchSt(b,k)).length+'</span></button>').join('')+'</div>'+
    '<div class="olist" id="ord-list">'+ordRows()+'</div></div>';
}

/* Расписание */
function viewSched(){
  let headRow='<th class="hn">Зал</th>';for(let i=0;i<24;i++)headRow+='<th>'+pad(hr(i))+'</th>';
  const rows=S.halls.map(h=>{let r='<th class="hn">'+esc(h.name)+'</th>';
    for(let i=0;i<24;i++){const b=busyBy(h.id,schedDate,i);
      if(!b){r+='<td class="free" data-cell="'+h.id+'|'+i+'" title="Свободно, нажмите чтобы забронировать"></td>';continue}
      const own=b.hall===h.id,tech=i<b.start||i>=b.start+b.hours;
      r+='<td class="c-'+b.status+(own?'':' c-all')+(tech?' tech':'')+'" data-open="'+b.id+'" title="№'+b.id+' · '+who(b)+(tech?' · тех. час':'')+'">'+(i===b.start&&own?'<b>'+b.id+'</b>':'')+'</td>'}
    return '<tr>'+r+'</tr>'}).join('');
  const dayB=bookings.filter(b=>b.date===schedDate&&['confirmed','review','awaiting'].includes(b.status));
  return '<div style="display:grid;gap:12px"><div class="sched-head"><button class="btn" data-sd="-1" aria-label="Предыдущий день">‹</button><b>'+fmtDate(schedDate)+'</b><button class="btn" data-sd="1" aria-label="Следующий день">›</button><input type="date" id="sd-pick" aria-label="Выбрать дату" value="'+schedDate+'"><button class="linkbtn" data-sd="0">Сегодня</button><span style="flex:1"></span><button class="btn" data-newblock>Закрыть время</button><button class="btn ok" data-new>+ Бронь</button></div>'+
    '<p class="note">'+brn(dayB.length)+' на '+rub(dayB.reduce((s,b)=>s+b.total,0))+'. Нажмите на свободную клетку, чтобы создать бронь, или на занятую, чтобы открыть её.</p>'+
    '<div class="scroll"><table class="grid"><thead><tr>'+headRow+'</tr></thead><tbody>'+rows+'</tbody></table></div>'+
    '<div class="legend"><span><i style="background:var(--accent-soft)"></i>забронировано</span><span><i style="background:repeating-linear-gradient(45deg,var(--surface-2) 0 3px,var(--grey-soft) 3px 6px)"></i>не подтверждено</span><span><i style="background:var(--amber-soft)"></i>ждёт оплату</span><span><i style="background:var(--grey-soft);border:1px solid var(--muted)"></i>закрыто</span><span><i style="background:var(--accent-soft);opacity:.55"></i>тех. час</span><span><i style="background:repeating-linear-gradient(45deg,transparent 0 3px,var(--line) 3px 4px)"></i>занято арендой всего зала</span></div></div>';
}

/* Клиенты */
function clientList(){
  const map={};
  bookings.filter(b=>b.status!=='blocked'&&digits(b.phone)).forEach(b=>{
    const k=digits(b.phone);const c=map[k]||(map[k]={phone:b.phone,name:b.name,n:0,hours:0,spent:0,last:null,next:null,cancels:0});
    if(b.status==='confirmed'){c.n++;c.hours+=b.hours;c.spent+=b.total;if(b.date<T(0)){if(!c.last||b.date>c.last)c.last=b.date}else if(!c.next||b.date<c.next)c.next=b.date}
    if(['cancelled','expired','rejected'].includes(b.status))c.cancels++;
  });
  return Object.values(map).sort((a,b)=>b.spent-a.spent);
}
function clientRows(){
  const qq=cq.trim().toLowerCase(),qd=digits(cq);
  const list=clientList().filter(c=>!qq||c.name.toLowerCase().includes(qq)||(qd.length>=3&&digits(c.phone).includes(qd)));
  if(!list.length)return '<tr><td colspan="7" class="note">Пока никого нет.</td></tr>';
  return list.map(c=>'<tr data-client="'+esc(c.phone)+'"><td><b>'+esc(c.name)+'</b>'+(c.n>=3?'<span class="flag ok">постоянный</span>':'')+'</td><td class="num">'+esc(c.phone)+'</td><td>'+c.n+'</td><td>'+c.hours+'</td><td>'+rub(c.spent)+'</td><td>'+(c.last?fmtDate(c.last):'—')+'</td><td>'+(c.next?fmtDate(c.next):'—')+(c.cancels?'<br><span class="note">отмен: '+c.cancels+'</span>':'')+'</td></tr>').join('');
}
function viewClients(){
  return '<div style="display:grid;gap:12px"><div class="toolbar"><input id="cl-q" type="search" placeholder="Поиск по имени или телефону" value="'+esc(cq)+'"></div>'+
    '<div class="scroll"><table class="st-table clients"><thead><tr><th>Клиент</th><th>Телефон</th><th>Броней</th><th>Часов</th><th>Потратил</th><th>Последний визит</th><th>Следующая бронь</th></tr></thead><tbody id="cl-list">'+clientRows()+'</tbody></table></div>'+
    '<p class="note">База собирается из броней по номеру телефона. Нажмите на клиента, чтобы увидеть все его брони.</p></div>';
}

/* Статистика */
function periodRange(){
  const t=parse(todayS);
  if(period==='7')return [T(-6),T(0)];
  if(period==='30')return [T(-29),T(0)];
  if(period==='month')return [ymd(new Date(t.getFullYear(),t.getMonth(),1)),ymd(new Date(t.getFullYear(),t.getMonth()+1,0))];
  if(period.startsWith('m:')){const [y,m]=period.slice(2).split('-').map(Number);return [ymd(new Date(y,m-1,1)),ymd(new Date(y,m,0))]}
  return ['0000','9999'];
}
function monthTitle(k){const [y,m]=k.split('-').map(Number);return MONN[m-1][0].toUpperCase()+MONN[m-1].slice(1)+' '+y}
function monthSelect(){
  const dates=bookings.map(b=>b.date).sort();const t=parse(todayS);const first=parse(dates[0]||todayS);
  const opts=[];let d=new Date(first.getFullYear(),first.getMonth(),1);const end=new Date(t.getFullYear(),t.getMonth()+2,1);
  while(d<=end){opts.push(d.getFullYear()+'-'+pad(d.getMonth()+1));d=new Date(d.getFullYear(),d.getMonth()+1,1)}
  const cur=period.startsWith('m:')?period.slice(2):'';
  return '<select id="st-month" class="mpick'+(cur?' on':'')+'" aria-label="Выбрать месяц"><option value="">Выбрать месяц</option>'+opts.reverse().map(k=>'<option value="'+k+'"'+(k===cur?' selected':'')+'>'+monthTitle(k)+'</option>').join('')+'</select>';
}
function viewStats(){
  const [from,to]=periodRange();
  const inP=bookings.filter(b=>b.date>=from&&b.date<=to&&b.status!=='blocked');
  const conf=inP.filter(b=>b.status==='confirmed');
  const received=conf.reduce((s,b)=>s+b.prepay+(b.fullPaid?b.total-b.prepay:0),0);
  const toCollect=conf.filter(b=>!b.fullPaid).reduce((s,b)=>s+b.total-b.prepay,0);
  const review=inP.filter(b=>b.status==='review'),awaiting=inP.filter(b=>b.status==='awaiting'),expired=inP.filter(b=>b.status==='expired');
  const lost=inP.filter(b=>['expired','cancelled','rejected'].includes(b.status));
  const revenue=conf.reduce((s,b)=>s+b.total,0),hours=conf.reduce((s,b)=>s+b.hours,0);
  const held=bookings.filter(b=>b.depositState==='held').reduce((s,b)=>s+b.deposit,0);
  const byHall=S.halls.map(h=>{const bs=conf.filter(b=>b.hall===h.id);return {h,n:bs.length,hours:bs.reduce((s,b)=>s+b.hours,0),rev:bs.reduce((s,b)=>s+b.total,0)}});
  const maxRev=Math.max(1,...byHall.map(x=>x.rev));
  const ph=conf.filter(b=>b.purpose==='photo'),ev=conf.filter(b=>b.purpose==='event');
  const PER=[['7','7 дней'],['30','30 дней'],['month','Этот месяц'],['all','Всё время']];
  return '<div style="display:grid;gap:14px">'+
    '<div class="periods">'+PER.map(([k,l])=>'<button data-p="'+k+'" aria-pressed="'+(period===k)+'">'+l+'</button>').join('')+monthSelect()+'</div>'+(period.startsWith('m:')?'<h4>'+monthTitle(period.slice(2))+'</h4>':'')+
    '<div class="kpis">'+
      '<div class="kpi good"><small>Поступило денег</small><b>'+rub(received)+'</b><span>предоплаты и доплаты по подтверждённым</span></div>'+
      '<div class="kpi"><small>Выручка по броням</small><b>'+rub(revenue)+'</b><span>'+brn(conf.length)+' · '+hoursWord(hours)+'</span></div>'+
      '<div class="kpi warn"><small>Ждёт доплаты на месте</small><b>'+rub(toCollect)+'</b><span>'+brn(conf.filter(b=>!b.fullPaid).length)+'</span></div>'+
      '<div class="kpi warn"><small>Не подтверждено</small><b>'+rub(review.reduce((s,b)=>s+b.prepay,0))+'</b><span>'+review.length+' переводов проверить</span></div>'+
      '<div class="kpi bad"><small>Не оплачено</small><b>'+(awaiting.length+expired.length)+'</b><span>'+awaiting.length+' ждут перевода, '+expired.length+' просрочено</span></div>'+
      '<div class="kpi"><small>Отмены и отказы</small><b>'+lost.length+'</b><span>упущено '+rub(lost.reduce((s,b)=>s+b.total,0))+'</span></div>'+
      '<div class="kpi"><small>Средний чек</small><b>'+rub(conf.length?revenue/conf.length:0)+'</b><span>фото '+rub(ph.length?ph.reduce((s,b)=>s+b.total,0)/ph.length:0)+' · мероприятия '+rub(ev.length?ev.reduce((s,b)=>s+b.total,0)/ev.length:0)+'</span></div>'+
      '<div class="kpi"><small>Залоги на руках</small><b>'+rub(held)+'</b><span>нужно вернуть клиентам</span></div>'+
    '</div>'+
    '<h4>Аренда по локациям</h4><div class="scroll"><table class="st-table"><thead><tr><th>Локация</th><th>Броней</th><th>Часов</th><th>Выручка</th><th class="barcell"></th></tr></thead><tbody>'+
      byHall.map(x=>'<tr><td><b>'+esc(x.h.name)+'</b></td><td>'+x.n+'</td><td>'+x.hours+'</td><td>'+rub(x.rev)+'</td><td class="barcell"><i style="width:'+(x.rev/maxRev*100).toFixed(1)+'%"></i></td></tr>').join('')+
    '</tbody></table></div>'+
    '<h4>Фото и мероприятия</h4><div class="scroll"><table class="st-table"><thead><tr><th>Формат</th><th>Броней</th><th>Часов</th><th>Выручка</th></tr></thead><tbody>'+
      [['Фотосессии',ph],['Мероприятия',ev]].map(([n,a])=>'<tr><td><b>'+n+'</b></td><td>'+a.length+'</td><td>'+a.reduce((s,b)=>s+b.hours,0)+'</td><td>'+rub(a.reduce((s,b)=>s+b.total,0))+'</td></tr>').join('')+
    '</tbody></table></div>'+
    '<p class="note">Считается по дате брони. «Поступило» включает предоплату после подтверждения и доплату, когда её отметили.</p></div>';
}

/* Настройки */
function viewSettings(){
  const inp=(id,v,num)=>'<input id="'+id+'" value="'+esc(v)+'"'+(num?' type="number" inputmode="decimal" step="any"':'')+'>';
  return '<form id="set-form" style="display:grid;gap:16px">'+
    '<div class="sec"><h4>Реквизиты для предоплаты</h4><div class="form2"><label for="s-card">Номер карты'+inp('s-card',S.pay.card)+'</label><label for="s-sbp">Телефон для СБП'+inp('s-sbp',S.pay.sbp)+'</label><label for="s-bank">Банк'+inp('s-bank',S.pay.bank)+'</label><label for="s-holder">Получатель'+inp('s-holder',S.pay.holder)+'</label></div></div>'+
    '<div class="sec"><h4>Сроки и предоплата</h4><div class="form2"><label for="s-paymin">Минут на перевод после заявки'+inp('s-paymin',S.payMin,1)+'</label><label for="s-confh">Часов на подтверждение'+inp('s-confh',S.confirmH,1)+'</label><label for="s-prepay">Предоплата, %'+inp('s-prepay',Math.round(S.prepay*100),1)+'</label></div></div>'+
    '<div class="sec"><h4>Фотостудия, ₽ за час</h4><div class="scroll"><table class="rates"><thead><tr><th>Локация</th><th>Будни</th><th>Выходные</th></tr></thead><tbody>'+S.halls.map(h=>'<tr><td>'+esc(h.name)+'</td><td>'+inp('s-wd-'+h.id,h.wd,1)+'</td><td>'+inp('s-we-'+h.id,h.we,1)+'</td></tr>').join('')+'</tbody></table></div>'+
      '<div class="form2"><label for="s-night">Нерабочее время 22:00–10:00, наценка %'+inp('s-night',Math.round((S.nightK-1)*100),1)+'</label><label for="s-gfree">Гостей без доплаты'+inp('s-gfree',S.guestFree,1)+'</label><label for="s-gfee">Доплата за гостя в час, ₽'+inp('s-gfee',S.guestFee,1)+'</label></div></div>'+
    '<div class="sec"><h4>Мероприятия, ₽ за час</h4><div class="scroll"><table class="rates"><thead><tr><th>Гостей</th><th>Будни (пн–чт)</th><th>Выходные и праздники</th></tr></thead><tbody>'+S.eventTiers.map((t,i)=>'<tr><td>до '+t.max+'</td><td>'+inp('s-twd-'+i,t.wd,1)+'</td><td>'+inp('s-twe-'+i,t.we,1)+'</td></tr>').join('')+'</tbody></table></div>'+
      '<div class="form2"><label for="s-tech">Доп. тех. час, ₽'+inp('s-tech',S.techFee,1)+'</label><label for="s-cyc">Циклорама на мероприятие, ₽'+inp('s-cyc',S.cycFee,1)+'</label></div></div>'+
    '<div class="sec"><h4>Telegram-бот</h4><p class="note">'+(TG.enabled?'Подключён'+(TG.botName?' (@'+esc(TG.botName)+')':'')+'. Получателей уведомлений: '+TG.admins+'. Добавить получателя можно в файле настроек сервера (TELEGRAM_ADMIN_CHAT_IDS).':'Не подключён. Укажите токен бота в настройках сервера (TELEGRAM_BOT_TOKEN), см. инструкцию.')+'</p></div>'+
    '<div class="actions"><button class="btn ok" type="submit">Сохранить настройки</button><span class="note">Новые цены действуют для новых броней. Уже созданные брони не пересчитываются.</span></div></form>';
}
async function saveSettings(){
  if(RO())return;
  const v=id=>document.getElementById(id).value.trim(),n=id=>+v(id);
  const s={pay:{card:v('s-card'),sbp:v('s-sbp'),bank:v('s-bank'),holder:v('s-holder')},payMin:n('s-paymin'),confirmH:n('s-confh'),prepay:n('s-prepay')/100,nightK:1+n('s-night')/100,guestFree:n('s-gfree'),guestFee:n('s-gfee'),techFee:n('s-tech'),cycFee:n('s-cyc'),
    halls:S.halls.map(h=>({id:h.id,wd:n('s-wd-'+h.id),we:n('s-we-'+h.id)})),eventTiers:S.eventTiers.map((t,i)=>({wd:n('s-twd-'+i),we:n('s-twe-'+i)}))};
  try{await api('/api/admin/settings',{method:'PUT',body:JSON.stringify({settings:s})});await refresh();toast('Настройки сохранены')}catch(e){toast(e.message)}
}

/* Карточка брони и новая бронь */
const drawer=document.getElementById('drawer'),DB=document.getElementById('dr-body');
function openB(id){openId=id;draft=null;moveOpen=false;cancelOpen=false;renderDrawer();setTimeout(()=>{const c=DB.querySelector('[data-close]');if(c)c.focus()},0)}
function closeDrawer(){openId=null;draft=null;renderDrawer()}
function renderDrawer(){
  if(openId==null&&!draft){drawer.hidden=true;return}
  drawer.hidden=false;
  if(draft){DB.innerHTML=viewDraft();bindDraft();return}
  const b=bookings.find(x=>x.id===openId);if(!b){closeDrawer();return}
  DB.innerHTML=viewDetail(b);
  const nt=document.getElementById('dr-note');if(nt&&!RO())nt.addEventListener('change',()=>{b.note=nt.value;api('/api/admin/bookings/'+b.id+'/action',{method:'POST',body:JSON.stringify({action:'note',note:nt.value})}).then(()=>toast('Заметка сохранена'),e=>toast(e.message))});
}
function row(k,v){return '<div class="row"><span>'+k+'</span><span>'+v+'</span></div>'}
function histHtml(b){return '<div class="sec"><h4>История</h4><ol class="hist">'+(b.history||[]).slice().reverse().map(h=>'<li><time class="num">'+new Date(h.t).toLocaleString('ru-RU',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})+'</time>'+esc(h.text)+'</li>').join('')+'</ol></div>'}
function viewDetail(b){
  const H=hall(b.hall);
  const top='<div class="dr-head"><div><h2 id="dr-title">№'+b.id+' · '+esc(H.name)+'</h2><p class="note">'+(b.source==='admin'?'Создана администратором':'Заявка с сайта')+' · '+new Date(b.createdAt).toLocaleString('ru-RU',{day:'numeric',month:'long',hour:'2-digit',minute:'2-digit'})+'</p></div><button class="back" data-close aria-label="Закрыть">✕</button></div><div>'+pill(b)+'</div>';
  if(b.status==='blocked')return top+'<div class="summary">'+row('Когда',fmtDate(b.date)+', '+span(b.start,b.hours))+row('Причина',esc(b.reason))+'</div><div class="actions"><button class="btn no" data-d="unblock">Открыть это время</button></div>'+histHtml(b);
  let act='';
  if(b.status==='review')act='<button class="btn ok" data-d="confirm">Деньги пришли — подтвердить</button><button class="btn no" data-d="reject">Перевода нет</button>';
  if(b.status==='awaiting')act='<button class="btn ok" data-d="confirm">Предоплата получена</button>'+(b.tg_chat?'<button class="btn" data-d="remind">Напомнить в Telegram</button>':'');
  if(b.status==='confirmed'&&!b.fullPaid)act='<button class="btn ok" data-d="full">Доплата '+rub(b.total-b.prepay)+' получена</button>';
  const live=['awaiting','review','confirmed'].includes(b.status)&&b.date>=T(0);
  const prepaid=b.status==='confirmed';
  const money='<div class="summary lines">'+(b.lines||[]).map(l=>'<div class="row"><span>'+esc(l[0])+'</span><span class="num">'+rub(l[1])+'</span></div>').join('')+
    '<div class="row big after"><span>Итого</span><span class="num">'+rub(b.total)+'</span></div>'+
    '<div class="row"><span>Предоплата</span><span class="num">'+rub(b.prepay)+' · <b class="'+(prepaid?'okc':'warnc')+'">'+(prepaid?'получена':b.status==='review'?'на проверке':b.status==='awaiting'?'не оплачена':'—')+'</b></span></div>'+
    '<div class="row"><span>Доплата на месте</span><span class="num">'+rub(b.total-b.prepay)+' · <b class="'+(b.fullPaid?'okc':'warnc')+'">'+(b.fullPaid?'получена':'ожидается')+'</b></span></div>'+
    (b.deposit?'<div class="row"><span>Залог</span><span class="num">'+rub(b.deposit)+' · <b class="'+(b.depositState==='returned'?'okc':'warnc')+'">'+({none:'не взят',held:'у нас',returned:'возвращён'})[b.depositState]+'</b></span></div>':'')+'</div>'+
    (b.deposit&&b.status==='confirmed'?'<div class="actions">'+(b.depositState==='none'?'<button class="btn" data-d="depin">Залог получен</button>':'')+(b.depositState==='held'?'<button class="btn" data-d="depout">Залог возвращён</button>':'')+'</div>':'');
  let move='';
  if(live){
    if(moveOpen){let o='';for(let i=0;i<24;i++)o+='<option value="'+i+'"'+(i===b.start?' selected':'')+'>'+pad(hr(i))+':00</option>';
      move='<div class="sec inset"><h4>Перенос</h4><div class="form2"><label for="mv-date">Дата<input type="date" id="mv-date" value="'+b.date+'"></label><label for="mv-start">Начало<select id="mv-start">'+o+'</select></label><label for="mv-hours">Часов<input type="number" id="mv-hours" min="1" value="'+b.hours+'"></label></div><p class="err" id="mv-err"></p><div class="actions"><button class="btn ok" data-d="movesave">Перенести</button><button class="btn" data-d="moveclose">Отмена</button></div></div>';
    }else move='<button class="btn" data-d="move">Перенести</button>';
  }
  let cancel='';
  if(live){
    if(cancelOpen)cancel='<div class="sec inset"><h4>Отмена брони</h4><label for="cn-reason">Причина<select id="cn-reason"><option>Клиент отменил</option><option>Клиент не пришёл</option><option>Не удалось перенести</option><option>Ошибка в брони</option><option>Другое</option></select></label><p class="note">Время освободится. Возврат предоплаты по правилам студии оформляется отдельно.</p><div class="actions"><button class="btn no" data-d="cancelsave">Отменить бронь</button><button class="btn" data-d="cancelclose">Не отменять</button></div></div>';
    else cancel='<button class="btn no" data-d="cancel">Отменить</button>';
  }
  return top+(act?'<div class="actions">'+act+'</div>':'')+
    '<div class="sec"><h4>Клиент</h4><div class="summary">'+row('Имя',esc(b.name))+row('Телефон','<span class="num">'+esc(b.phone)+'</span> <button class="copy" data-copy="'+esc(b.phone)+'">Копировать</button>')+(b.email?row('Email',esc(b.email)):'')+row('Гостей',b.guests)+row('Формат',(b.purpose==='event'?'Мероприятие · ':'Фото · ')+esc(b.format))+(b.comment?row('Комментарий','«'+esc(b.comment)+'»'):'')+row('Telegram',b.tg_chat?'уведомления подключены':'не подключён')+'</div></div>'+
    '<div class="sec"><h4>Время</h4><div class="summary">'+row('Дата',fmtDate(b.date))+row('Время','<span class="num">'+span(b.start,b.hours)+'</span>')+(b.pre||b.post?row('Тех. часы','<span class="num">с '+pad(hr(b.start-b.pre))+':00 до '+pad(hr(b.start+b.hours+b.post))+':00</span>'):'')+'</div>'+(live?'<div class="actions">'+(moveOpen?'':move)+(cancelOpen?'':cancel)+'</div>':'')+(moveOpen?move:'')+(cancelOpen?cancel:'')+'</div>'+
    '<div class="sec"><h4>Деньги</h4>'+money+'</div>'+
    '<div class="sec"><h4>Заметка администратора</h4><textarea id="dr-note" placeholder="Видна только администраторам. Сохраняется, когда вы уходите из поля.">'+esc(b.note)+'</textarea></div>'+histHtml(b);
}
function newDraft(o){if(RO())return;draft=Object.assign({kind:'booking',hall:S.halls[0].id,date:schedDate||todayS,start:6,hours:1,purpose:'photo',guests:2,format:S.photoFormats[0],name:'',phone:'',pay:'prepaid',discount:0,reason:'',cleaning:S.cleaning[0].price},o||{});openId=null;renderDrawer()}
function draftOrder(){const d=draft;return {purpose:d.purpose,hall:d.hall,date:d.date,start:d.start,hours:d.hours,guests:d.guests,evt:d.purpose==='event'?{cleaning:d.cleaning,tech:0,cyc:false,extras:[]}:null,discount:d.discount}}
function viewDraft(){
  const d=draft;let opts='';for(let i=0;i<24;i++)opts+='<option value="'+i+'"'+(i===d.start?' selected':'')+'>'+pad(hr(i))+':00</option>';
  const block=d.kind==='block',pp=!block&&d.purpose==='event'?1:0;
  const ok=P.fits(busyList(d.date),d.hall,d.start,d.hours,pp,pp);
  const pr=block?null:P.calc(S,draftOrder());
  const formats=d.purpose==='event'?S.eventFormats:S.photoFormats;
  return '<div class="dr-head"><div><h2 id="dr-title">'+(block?'Закрыть время':'Новая бронь')+'</h2><p class="note">'+(block?'Например, ремонт или своя съёмка. Клиенты увидят это время занятым.':'Для броней по звонку или в мессенджере.')+'</p></div><button class="back" data-close aria-label="Закрыть">✕</button></div>'+
    '<div class="toggle"><button data-k="booking" aria-pressed="'+!block+'">Бронь</button><button data-k="block" aria-pressed="'+block+'">Закрыть время</button></div>'+
    '<div class="form2"><label for="nf-hall">Локация<select id="nf-hall">'+S.halls.map(h=>'<option value="'+h.id+'"'+(h.id===d.hall?' selected':'')+'>'+esc(h.name)+'</option>').join('')+'</select></label>'+
    '<label for="nf-date">Дата<input type="date" id="nf-date" value="'+d.date+'"></label><label for="nf-start">Начало<select id="nf-start">'+opts+'</select></label><label for="nf-hours">Часов<input type="number" id="nf-hours" min="1" max="24" value="'+d.hours+'"></label></div>'+
    (ok?'':'<p class="err">Это время пересекается с другой бронью'+(pp?' или тех. часами':'')+'.</p>')+
    (block?'<label for="nf-reason">Причина<input id="nf-reason" value="'+esc(d.reason)+'" placeholder="Ремонт, своя съёмка, уборка"></label>':
    (d.hall==='all'?'<div class="toggle"><button data-pp="photo" aria-pressed="'+(d.purpose==='photo')+'">Фотосессия</button><button data-pp="event" aria-pressed="'+(d.purpose==='event')+'">Мероприятие</button></div>':'')+
    '<div class="form2"><label for="nf-guests">Гостей<input type="number" id="nf-guests" min="1" max="150" value="'+d.guests+'"></label><label for="nf-format">Формат<select id="nf-format">'+formats.map(f=>'<option'+(f===d.format?' selected':'')+'>'+esc(f)+'</option>').join('')+'</select></label>'+
    (d.purpose==='event'?'<label for="nf-clean">Клининг<select id="nf-clean">'+S.cleaning.map(c=>'<option value="'+c.price+'"'+(c.price===d.cleaning?' selected':'')+'>'+esc(c.name)+', '+rub(c.price)+'</option>').join('')+'</select></label>':'')+
    '<label for="nf-name">Имя клиента<input id="nf-name" value="'+esc(d.name)+'"></label><label for="nf-phone">Телефон<input id="nf-phone" type="tel" value="'+esc(d.phone)+'"></label>'+
    '<label for="nf-disc">Скидка, ₽<input type="number" id="nf-disc" min="0" value="'+d.discount+'"></label>'+
    '<label for="nf-pay">Оплата<select id="nf-pay"><option value="prepaid"'+(d.pay==='prepaid'?' selected':'')+'>Предоплата получена</option><option value="full"'+(d.pay==='full'?' selected':'')+'>Оплачено полностью</option><option value="awaiting"'+(d.pay==='awaiting'?' selected':'')+'>Ждёт оплату</option></select></label></div>'+
    '<div class="summary lines">'+pr.lines.map(l=>'<div class="row"><span>'+esc(l[0])+'</span><span class="num">'+rub(l[1])+'</span></div>').join('')+'<div class="row big after"><span>Итого</span><span class="num">'+rub(pr.total)+'</span></div><div class="row"><span>Предоплата</span><span class="num">'+rub(pr.prepay)+'</span></div></div>')+
    '<p class="err" id="nf-err"></p><div class="actions"><button class="btn ok" data-d="draftsave"'+(ok?'':' disabled')+'>'+(block?'Закрыть время':'Создать бронь')+'</button><button class="btn" data-close>Отмена</button></div>';
}
function bindDraft(){
  const on=(id,ev,fn)=>{const el=document.getElementById(id);if(el)el.addEventListener(ev,()=>fn(el))};
  on('nf-hall','change',el=>{draft.hall=el.value;if(el.value!=='all'&&draft.purpose==='event'){draft.purpose='photo';draft.format=S.photoFormats[0]}renderDrawer()});
  on('nf-date','change',el=>{if(el.value)draft.date=el.value;renderDrawer()});
  on('nf-start','change',el=>{draft.start=+el.value;renderDrawer()});
  on('nf-hours','change',el=>{draft.hours=Math.max(1,Math.min(24,+el.value||1));renderDrawer()});
  on('nf-guests','change',el=>{draft.guests=Math.max(1,Math.min(150,+el.value||1));renderDrawer()});
  on('nf-format','change',el=>{draft.format=el.value});
  on('nf-clean','change',el=>{draft.cleaning=+el.value;renderDrawer()});
  on('nf-disc','change',el=>{draft.discount=Math.max(0,+el.value||0);renderDrawer()});
  on('nf-pay','change',el=>{draft.pay=el.value});
  on('nf-name','input',el=>{draft.name=el.value});on('nf-phone','input',el=>{draft.phone=el.value});on('nf-reason','input',el=>{draft.reason=el.value});
}
async function saveDraft(){
  if(RO())return;
  const d=draft,err=document.getElementById('nf-err');
  const body=d.kind==='block'?{kind:'block',hall:d.hall,date:d.date,start:d.start,hours:d.hours,reason:d.reason}:Object.assign(draftOrder(),{format:d.format,name:d.name,phone:d.phone,pay:d.pay});
  try{const j=await api('/api/admin/bookings',{method:'POST',body:JSON.stringify(body)});draft=null;bookings.push(norm(j.booking));renderAdmin();refresh().catch(()=>{});if(d.kind!=='block')openB(j.booking.id);toast(d.kind==='block'?'Время закрыто':'Бронь №'+j.booking.id+' создана')}
  catch(e){err.textContent=e.message}
}
async function act(id,action,extra){
  if(RO())return;
  try{const j=await api('/api/admin/bookings/'+id+'/action',{method:'POST',body:JSON.stringify(Object.assign({action},extra||{}))});moveOpen=false;cancelOpen=false;
    {const nb=norm(j.booking),i=bookings.findIndex(x=>x.id===nb.id);if(i>=0)bookings[i]=nb;else bookings.push(nb)}renderAdmin();refresh().catch(()=>{});
    toast({confirm:'Бронь подтверждена',reject:'Бронь отклонена',full:'Доплата отмечена',depin:'Залог отмечен',depout:'Залог возвращён',remind:'Напоминание отправлено',cancel:'Бронь отменена',move:'Бронь перенесена',unblock:'Время открыто'}[action]||'Готово');
    if(action==='unblock')closeDrawer();
  }catch(e){const er=document.getElementById(action==='move'?'mv-err':'nf-err');if(er)er.textContent=e.message;else toast(e.message)}
}

/* события */
document.getElementById('adm-nav').addEventListener('click',e=>{const t=e.target.closest('[data-v]');if(!t)return;view=t.dataset.v;renderAdmin()});
AM.addEventListener('click',e=>{
  const t=e.target.closest('[data-open],[data-q],[data-goto],[data-new],[data-newblock],[data-fs],[data-sd],[data-p],[data-cell],[data-client]');if(!t)return;
  const d=t.dataset;
  if(d.q){act(+d.id,d.q);return}
  if(d.open){openB(+d.open);return}
  if(d.goto){view='orders';fStatus=d.goto;q='';renderAdmin();return}
  if(d.new!==undefined){newDraft({date:view==='sched'?schedDate:todayS});return}
  if(d.newblock!==undefined){newDraft({kind:'block',date:schedDate});return}
  if(d.fs){fStatus=d.fs;renderAdmin();return}
  if(d.sd!==undefined){const n=+d.sd;if(n===0)schedDate=todayS;else{const x=parse(schedDate);x.setDate(x.getDate()+n);schedDate=ymd(x)}renderAdmin();return}
  if(d.p){period=d.p;renderAdmin();return}
  if(d.cell){const [h,i]=d.cell.split('|');newDraft({hall:h,date:schedDate,start:+i});return}
  if(d.client){view='orders';fStatus='all';q=d.client;renderAdmin();return}
});
AM.addEventListener('change',e=>{if(e.target.id==='sd-pick'&&e.target.value){schedDate=e.target.value;renderAdmin()}if(e.target.id==='st-month'){period=e.target.value?'m:'+e.target.value:'month';renderAdmin()}});
AM.addEventListener('submit',e=>{if(e.target.id==='set-form'){e.preventDefault();saveSettings()}});
drawer.addEventListener('click',e=>{
  const t=e.target.closest('[data-close],[data-d],[data-k],[data-pp],[data-copy]');if(!t||t.disabled)return;
  const d=t.dataset;
  if(d.close!==undefined){closeDrawer();return}
  if(d.copy){navigator.clipboard&&navigator.clipboard.writeText(d.copy).then(()=>toast('Скопировано'),()=>{});return}
  if(d.k){draft.kind=d.k;renderDrawer();return}
  if(d.pp){draft.purpose=d.pp;draft.format=(d.pp==='event'?S.eventFormats:S.photoFormats)[0];if(d.pp==='event'){draft.hours=Math.max(4,draft.hours);draft.guests=Math.max(20,draft.guests)}renderDrawer();return}
  if(d.d==='draftsave'){saveDraft();return}
  if(openId==null)return;
  if(d.d==='move'){moveOpen=true;renderDrawer();return}
  if(d.d==='moveclose'){moveOpen=false;renderDrawer();return}
  if(d.d==='movesave'){act(openId,'move',{date:document.getElementById('mv-date').value,start:+document.getElementById('mv-start').value,hours:+document.getElementById('mv-hours').value});return}
  if(d.d==='cancel'){cancelOpen=true;renderDrawer();return}
  if(d.d==='cancelclose'){cancelOpen=false;renderDrawer();return}
  if(d.d==='cancelsave'){act(openId,'cancel',{reason:document.getElementById('cn-reason').value});return}
  if(d.d==='unblock'){act(openId,'cancel',{reason:'Время открыто'}).then(()=>closeDrawer());return}
  act(openId,d.d);
});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!drawer.hidden)closeDrawer()});
let tt;function toast(s){const el=document.getElementById('toast');el.textContent=s;el.classList.add('show');clearTimeout(tt);tt=setTimeout(()=>el.classList.remove('show'),2400)}

async function refresh(){await load();renderAdmin()}
function typing(){const a=document.activeElement;return a&&['INPUT','TEXTAREA','SELECT'].includes(a.tagName)}
setInterval(()=>{if(!document.getElementById('app').hidden&&!typing()&&!draft&&!moveOpen&&!cancelOpen)refresh().catch(()=>{})},30000);

function showLogin(){document.getElementById('app').hidden=true;document.getElementById('login').hidden=false;setTimeout(()=>document.getElementById('pw').focus(),0)}
document.getElementById('login-form').addEventListener('submit',async e=>{
  e.preventDefault();const err=document.getElementById('login-err');err.textContent='';
  try{await api('/api/admin/login',{method:'POST',body:JSON.stringify({password:document.getElementById('pw').value})});start()}catch(ex){err.textContent=ex.message}
});
document.getElementById('logout').addEventListener('click',async()=>{await api('/api/admin/logout',{method:'POST'}).catch(()=>{});showLogin()});
async function start(){
  try{await load()}catch(e){return}
  document.getElementById('login').hidden=true;document.getElementById('app').hidden=false;renderAdmin();
}
start();
})();
