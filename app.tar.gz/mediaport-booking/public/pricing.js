/* Общие правила цен и времени. Один файл для сервера (require) и браузера (window.Pricing). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Pricing = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const HOLIDAYS = ['01-01','01-02','01-03','01-04','01-05','01-06','01-07','01-08','02-23','03-08','05-01','05-09','06-12','11-04','12-31'];
  const pad = n => String(n).padStart(2, '0');
  const parse = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const hr = i => (6 + i) % 24;                 /* индекс слота 0..23 → час; сутки 06:00–06:00 */
  const isHoliday = s => HOLIDAYS.includes(s.slice(5));
  const isWe = s => [5, 6, 0].includes(parse(s).getDay()) || isHoliday(s);
  const isNight = i => { const c = hr(i); return c < 10 || c >= 22; };
  const hoursWord = n => n + ' ' + (n % 10 === 1 && n % 100 !== 11 ? 'час' : (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 'часа' : 'часов'));
  const rub = n => Math.round(n).toLocaleString('ru-RU') + ' ₽';
  const tierOf = (S, g) => S.eventTiers.find(t => g <= t.max) || S.eventTiers[S.eventTiers.length - 1];
  const prePost = (purpose, tech) => purpose === 'event' ? [1, 1 + (tech || 0)] : [0, 0];

  /* o: {purpose, hall, date, start, hours, guests, evt:{cleaning,tech,cyc,extras[]}, discount}; S: настройки */
  function calc(S, o) {
    const we = isWe(o.date), lines = []; let rent = 0, deposit = 0;
    if (o.purpose === 'event') {
      const t = tierOf(S, +o.guests || 1), rate = we ? t.we : t.wd;
      rent = rate * o.hours;
      lines.push(['Аренда зала: ' + hoursWord(o.hours) + ' × ' + rub(rate) + ' (до ' + t.max + ' гостей' + (we ? ', выходной' : '') + ')', rent]);
      const ev = o.evt || {};
      if (ev.tech) lines.push(['Доп. тех. часы: ' + ev.tech + ' × ' + rub(S.techFee), ev.tech * S.techFee]);
      if (ev.cyc) lines.push(['Зона циклорамы на всё мероприятие', S.cycFee]);
      if (ev.cleaning) { const c = S.cleaning.find(x => x.price === ev.cleaning); if (c) lines.push(['Клининг: ' + c.name.toLowerCase(), c.price]); }
      (ev.extras || []).forEach(id => { const x = S.extras.find(e => e.id === id); if (x) lines.push([x.name, x.price]); });
      deposit = Math.round(rent * 0.5);
    } else {
      const h = S.halls.find(x => x.id === o.hall), base = we ? h.we : h.wd; let night = 0, nightH = 0;
      for (let k = 0; k < o.hours; k++) if (isNight(o.start + k)) { night += base * (S.nightK - 1); nightH++; }
      rent = base * o.hours;
      lines.push(['Аренда: ' + hoursWord(o.hours) + ' × ' + rub(base) + (we ? ' (выходной)' : ''), rent]);
      if (night) lines.push(['Нерабочее время +' + Math.round((S.nightK - 1) * 100) + '%: ' + hoursWord(nightH), night]);
      const extra = Math.max(0, (+o.guests || 0) - S.guestFree);
      if (extra) lines.push(['Гости сверх ' + S.guestFree + ': ' + extra + ' × ' + S.guestFee + ' ₽ × ' + hoursWord(o.hours), extra * S.guestFee * o.hours]);
    }
    if (o.discount > 0) lines.push(['Скидка', -o.discount]);
    const total = Math.max(0, Math.round(lines.reduce((s, l) => s + l[1], 0)));
    return { lines, total, rent, deposit, prepay: Math.round(total * S.prepay) };
  }

  /* занятые интервалы: [{hall, start, end, status}] — проверка, свободно ли [start-pre, start+hours+post) */
  function overlaps(busy, hall, a, b) {
    return busy.find(x => (x.hall === hall || x.hall === 'all' || hall === 'all') && a < x.end && b > x.start);
  }
  function fits(busy, hall, start, hours, pre, post) {
    const a = start - (pre || 0), b = start + hours + (post || 0);
    if (a < 0 || b > 24 || hours < 1) return false;
    return !overlaps(busy, hall, a, b);
  }

  return { HOLIDAYS, pad, parse, ymd, hr, isHoliday, isWe, isNight, hoursWord, rub, tierOf, prePost, calc, overlaps, fits };
});
