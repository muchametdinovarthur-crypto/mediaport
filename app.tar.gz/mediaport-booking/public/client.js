(function(){
'use strict';
const P=window.Pricing;
const {pad,parse,ymd,hr,isWe,isNight,hoursWord,rub}=P;
const MON=['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
const MONN=['январь','февраль','март','апрель','май','июнь','июль','август','сентябрь','октябрь','ноябрь','декабрь'];
const WD=['вс','пн','вт','ср','чт','пт','сб'];
const PARTS=[['Утро',0],['День',6],['Вечер',12],['Ночь',18]];
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtDate=s=>{const d=parse(s);return d.getDate()+' '+MON[d.getMonth()]+', '+WD[d.getDay()]};
const span=(start,hours)=>pad(hr(start))+':00–'+pad(hr(start+hours))+':00'+(start+hours>18?' (до утра)':'');
const clock=t=>{const d=new Date(t);return pad(d.getHours())+':'+pad(d.getMinutes())};
const left=ms=>{ms=Math.max(0,ms);const s=Math.floor(ms/1000);return pad(Math.floor(s/3600))+':'+pad(Math.floor(s%3600/60))+':'+pad(s%60)};
function slotTime(date,i){const d=parse(date);d.setHours(6+i,0,0,0);return d.getTime()}

let S=null, skew=0;
const nowMs=()=>Date.now()+skew;
const C=document.getElementById('client');
const hall=id=>S.halls.find(h=>h.id===id);
const dayCache={}, monthCache={};

async function api(path,opts){
  const r=await fetch(path,Object.assign({headers:{'content-type':'application/json'}},opts||{}));
  let j={};try{j=await r.json()}catch(_){}
  if(!r.ok){const e=new Error(j.error||'Ошибка связи. Попробуйте ещё раз.');e.status=r.status;throw e}
  return j;
}
async function loadDay(date,force){if(force||!dayCache[date]){const j=await api('/api/day?date='+date);dayCache[date]=j.busy}return dayCache[date]}
async function loadMonth(m,purpose,force){const k=m+'|'+purpose;if(force||!monthCache[k]){const j=await api('/api/month?month='+m+'&purpose='+purpose);monthCache[k]=j.days}return monthCache[k]}

/* занятость с учётом прошедших часов */
function busyOf(date){const b=(dayCache[date]||[]).slice();for(let i=0;i<24;i++)if(slotTime(date,i)<nowMs())b.push({hall:'all',start:i,end:i+1,status:'past'});return b}
function occAt(hid,date,i){return (dayCache[date]||[]).find(x=>(x.hall===hid||x.hall==='all'||hid==='all')&&i>=x.start&&i<x.end)}
const isPast=(date,i)=>slotTime(date,i)<nowMs();

const blank=()=>{const t=parse(S.today);return {step:1,purpose:null,month:new Date(t.getFullYear(),t.getMonth(),1),date:null,hall:null,start:null,hours:1,guests:2,format:'',evt:{cleaning:0,tech:0,cyc:false,extras:[]},name:'',email:'',phone:'',comment:'',agree1:false,agree2:false,booking:null,token:null,busy:false}};
let cs;
const isEvt=()=>cs.purpose==='event';
const minH=()=>isEvt()?4:1;
const prePost=()=>P.prePost(cs.purpose,cs.evt.tech);
const fitsCs=(start,hours)=>{const [a,b]=prePost();return P.fits(busyOf(cs.date),cs.hall,start,hours,a,b)};
function hallHasRoom(hid,date){const b=busyOf(date);for(let i=0;i<24;i++)if(P.fits(b,hid,i,1,0,0))return true;return false}
const ORDER={photo:[1,2,3,4,6,7],event:[1,2,4,5,6,7]};
function bar(){const o=ORDER[cs.purpose||'photo'];const n=Math.max(1,o.indexOf(cs.step)+1);return '<div class="steps" aria-hidden="true">'+[1,2,3,4,5,6].map(i=>'<b class="'+(i<=n?'on':'')+'"></b>').join('')+'</div>'}
function head(back){return '<div class="studio"><div class="brand"><div class="logo">МЕДИАПОРТ</div><div><small>'+esc(S.studio.tagline)+'</small><b>'+esc(S.studio.name)+'</b></div></div>'+(back?'<button class="back" data-back>← Назад</button>':'')+'</div>'}
const phStyle=h=>' style="background-image:url(/img/'+esc(h.photo)+')"';
function linesHtml(pr,showPrepay){
  return '<div class="summary lines">'+pr.lines.map(l=>'<div class="row"><span>'+esc(l[0])+'</span><span class="num">'+rub(l[1])+'</span></div>').join('')+
    '<div class="row big after"><span>Итого</span><span class="num">'+rub(pr.total)+'</span></div>'+
    (showPrepay?'<div class="row"><span>Предоплата '+Math.round(S.prepay*100)+'%</span><span class="num">'+rub(pr.prepay)+'</span></div>':'')+
    (pr.deposit?'<div class="row"><span>Залог в день мероприятия, вернём на следующий день</span><span class="num">'+rub(pr.deposit)+'</span></div>':'')+'</div>';
}
const order=()=>({purpose:cs.purpose,hall:cs.hall,date:cs.date,start:cs.start,hours:cs.hours,guests:+cs.guests,evt:isEvt()?cs.evt:null});

function viewPurpose(){
  return head(false)+bar()+'<h2>Для чего бронируете?</h2><div class="purpose">'+
    '<button class="opt" data-purpose="photo"><b>Аренда для фото</b><small>Любая локация или весь зал, от 1 часа. Бронь 24/7.</small></button>'+
    '<button class="opt" data-purpose="event"><b>Под мероприятие или праздник</b><small>Весь зал до '+S.maxGuests+' гостей, от 4 часов. Звук, свет, проектор и мебель включены.</small></button></div>';
}
function viewDate(days){
  const m=cs.month,y=m.getFullYear(),mo=m.getMonth(),t=parse(S.today);
  const lead=(new Date(y,mo,1).getDay()+6)%7, dn=new Date(y,mo+1,0).getDate();
  const minM=new Date(t.getFullYear(),t.getMonth(),1), maxM=new Date(t.getFullYear(),t.getMonth()+2,1);
  let cells=['пн','вт','ср','чт','пт','сб','вс'].map(w=>'<span class="wd">'+w+'</span>').join('');
  for(let i=0;i<lead;i++)cells+='<span></span>';
  const maxDate=new Date(t);maxDate.setDate(maxDate.getDate()+S.maxDaysAhead);
  for(let d=1;d<=dn;d++){
    const s=ymd(new Date(y,mo,d)),dt=parse(s);
    if(dt<t||dt>maxDate){cells+='<button class="day" disabled>'+d+'</button>';continue}
    const full=days[s]==='full';
    cells+='<button class="day '+(full?'full':'free')+(isWe(s)?' we':'')+'" data-date="'+s+'" aria-label="'+d+' '+MON[mo]+(full?', всё занято':'')+'">'+d+'</button>';
  }
  return head(true)+bar()+'<div><h2>Выберите свободную дату</h2><p class="note">'+(isEvt()?'Мероприятие, весь зал':'Аренда для фото')+'</p></div>'+
    '<div class="cal-head"><b>'+MONN[mo]+' '+y+'</b><div class="cal-nav"><button data-mon="-1" aria-label="Предыдущий месяц"'+(m<=minM?' disabled':'')+'>‹</button><button data-mon="1" aria-label="Следующий месяц"'+(m>=maxM?' disabled':'')+'>›</button></div></div>'+
    '<div class="cal">'+cells+'</div><div class="legend"><span><i style="background:var(--accent-soft)"></i>есть свободное время</span><span><i style="background:var(--red-soft)"></i>всё занято</span><span><b>жирным</b> выходные и праздники</span></div>';
}
function viewHall(){
  return head(true)+bar()+'<div><h2>Выберите локацию</h2><p class="note">'+fmtDate(cs.date)+(isWe(cs.date)?' · тариф выходного дня':' · тариф будней')+'</p></div><div class="halls">'+
    S.halls.map(h=>{const room=hallHasRoom(h.id,cs.date);const base=isWe(cs.date)?h.we:h.wd;
      return '<button class="hall'+(h.wide?' wide':'')+'" data-hall="'+h.id+'"'+(room?'':' disabled')+'><span class="ph"'+phStyle(h)+' aria-hidden="true"></span><span class="t"><b>'+esc(h.name)+'</b><small>'+[h.area?h.area+' м²':'',h.cap?'до '+h.cap+' гостей':''].filter(Boolean).join(' · ')+'</small><small class="num">'+(room?'от '+rub(base)+'/ч':'на эту дату занято')+'</small></span></button>'}).join('')+'</div>';
}
function viewTime(){
  const H=hall(cs.hall),M=minH(),[pre,post]=prePost();
  if(cs.hours<M)cs.hours=M;
  if(cs.start!==null&&!fitsCs(cs.start,cs.hours)){cs.hours=M;if(!fitsCs(cs.start,cs.hours))cs.start=null}
  const canMinus=cs.hours>M, canPlus=cs.start===null?cs.hours<20:fitsCs(cs.start,cs.hours+1);
  const rows=PARTS.map(([name,s])=>{let b='';for(let i=s;i<s+6;i++){
      const c=hr(i), o=isPast(cs.date,i)?null:occAt(cs.hall,cs.date,i);
      if(o){const conf=o.status==='confirmed';b+='<button class="slot '+(conf?'booked':'pending')+'" aria-disabled="true" data-occ="'+o.status+'" title="'+(conf?'Забронировано':'Забронировано, но пока не подтверждено')+'">'+pad(c)+':00<small>'+(conf?'занято':'не подтв.')+'</small></button>';continue}
      const ok=fitsCs(i,M);let cls='slot';if(!isEvt()&&isNight(i))cls+=' night';
      if(cs.start!==null){if(i===cs.start)cls+=' sel';else if(i>cs.start&&i<cs.start+cs.hours)cls+=' in';else if(i>=cs.start-pre&&i<cs.start+cs.hours+post)cls+=' tech'}
      b+='<button class="'+cls+'" data-slot="'+i+'"'+(ok?'':' disabled')+'>'+pad(c)+':00'+(cls.includes('tech')?'<small>тех.</small>':'')+'</button>'}
    return '<div class="part"><span>'+name+'</span><div class="slots">'+b+'</div></div>'}).join('');
  const formats=isEvt()?S.eventFormats:S.photoFormats;
  if(!formats.includes(cs.format))cs.format='';
  const g=+cs.guests||0;let hint='';
  if(isEvt()){const t=P.tierOf(S,g);hint='<p class="hint">До '+t.max+' гостей: '+rub(isWe(cs.date)?t.we:t.wd)+' в час'+(isWe(cs.date)?' (выходной)':' (будни)')+'. Плюс по 1 бесплатному тех. часу до и после.</p>'}
  else if(g>S.guestFree)hint='<p class="hint">Больше '+S.guestFree+' человек: +'+S.guestFee+' ₽ в час за каждого сверх '+S.guestFree+'.</p>';
  const pr=cs.start!==null?P.calc(S,order()):null;
  const gallery=H.gallery&&H.gallery.length?'<div><div class="gallery" aria-label="Фото: '+esc(H.name)+'">'+H.gallery.map((f,n)=>'<div class="hero ph" style="background-image:url(/img/'+esc(f)+')" role="img" aria-label="'+esc(H.name)+', фото '+(n+1)+'"></div>').join('')+'</div><p class="note" style="margin-top:4px">Листайте фото →</p></div>':'<div class="hero ph"'+phStyle(H)+' role="img" aria-label="'+esc(H.name)+'"></div>';
  const cap=H.cap||S.maxGuests;
  return head(true)+bar()+gallery+
    '<div><h2>'+esc(H.name)+'</h2><p class="note">'+fmtDate(cs.date)+(isWe(cs.date)?' · выходной тариф':'')+'</p></div>'+
    (cs.hall==='all'?'<div class="toggle" role="group" aria-label="Формат аренды всего зала"><button data-mode="photo" aria-pressed="'+!isEvt()+'">Фотосессия</button><button data-mode="event" aria-pressed="'+isEvt()+'">Мероприятие</button></div>':'')+
    '<div class="fields"><label for="f-guests">Сколько человек<div class="stepper"><button data-g="-1" aria-label="Меньше">−</button><input id="f-guests" type="number" inputmode="numeric" min="1" max="'+cap+'" value="'+esc(cs.guests)+'"><button data-g="1" aria-label="Больше">+</button></div></label>'+
    '<label for="f-format">'+(isEvt()?'Формат мероприятия':'Формат съёмки')+'<select id="f-format"><option value="">Выберите</option>'+formats.map(f=>'<option'+(f===cs.format?' selected':'')+'>'+esc(f)+'</option>').join('')+'</select></label></div>'+hint+
    '<div class="time-head"><b>Время</b><div class="dur" aria-label="Длительность"><button data-dur="-1" aria-label="Меньше"'+(canMinus?'':' disabled')+'>−</button><b class="num">'+hoursWord(cs.hours)+'</b><button data-dur="1" aria-label="Больше"'+(canPlus?'':' disabled')+'>+</button></div></div>'+
    '<div class="parts">'+rows+'</div>'+
    '<div class="legend"><span><i style="background:var(--accent)"></i>начало</span>'+(isEvt()?'<span><i style="background:var(--amber-soft);border:1px solid var(--amber)"></i>тех. час</span>':'<span><i style="border:1px dashed var(--line)"></i>нерабочее время +'+Math.round((S.nightK-1)*100)+'%</span>')+'<span><i style="background:var(--grey-soft)"></i>забронировано</span><span><i style="background:repeating-linear-gradient(45deg,var(--surface-2) 0 3px,var(--grey-soft) 3px 6px);border:1px dashed var(--line)"></i>забронировано, но пока не подтверждено</span></div>'+
    (pr?'<div><p class="note" style="margin-bottom:6px">'+span(cs.start,cs.hours)+'</p>'+linesHtml(pr,!isEvt())+'</div>':'<p class="note">Выберите время начала. Минимум '+hoursWord(M)+'.</p>')+
    '<p class="err" id="t-err"></p><button class="cta" data-next'+(cs.start===null?' disabled':'')+'>'+(isEvt()?'Далее: опции':'Далее: контакты')+'</button>';
}
function viewOptions(){
  const ev=cs.evt,pr=P.calc(S,order());
  return head(true)+bar()+'<div><h2>Опции мероприятия</h2><p class="note">'+fmtDate(cs.date)+', '+span(cs.start,cs.hours)+' · '+cs.guests+' гостей</p></div>'+
    '<fieldset><legend>Клининг, обязательно</legend>'+S.cleaning.map(c=>'<label class="opt-row"><input type="radio" name="clean" data-clean="'+c.price+'"'+(ev.cleaning===c.price?' checked':'')+'><span>'+esc(c.name)+'<br><small class="note">'+esc(c.note)+'</small></span><span class="pr">'+rub(c.price)+'</span></label>').join('')+'</fieldset>'+
    '<fieldset><legend>Площадка</legend><label class="opt-row"><input type="checkbox" data-cyc'+(ev.cyc?' checked':'')+'><span>Зона циклорамы<br><small class="note">не входит в аренду, нужно застелить чистым покрытием</small></span><span class="pr">'+rub(S.cycFee)+'</span></label>'+
    '<div class="opt-row" style="grid-template-columns:minmax(0,1fr) auto"><span>Доп. тех. часы после мероприятия<br><small class="note">1 час до и 1 час после уже бесплатно</small></span><div class="stepper"><button data-tech="-1" aria-label="Меньше"'+(ev.tech?'':' disabled')+'>−</button><b class="num" style="min-width:22px;text-align:center">'+ev.tech+'</b><button data-tech="1" aria-label="Больше">+</button></div></div></fieldset>'+
    '<fieldset><legend>Доп. оборудование, по запросу заранее</legend>'+S.extras.map(x=>'<label class="opt-row"><input type="checkbox" data-extra="'+esc(x.id)+'"'+(ev.extras.includes(x.id)?' checked':'')+'><span>'+esc(x.name)+'</span><span class="pr">'+rub(x.price)+'</span></label>').join('')+'</fieldset>'+
    '<details><summary>Что входит в аренду</summary><ul><li>Фоновый звук, цветной свет, проектор (с вашим ноутбуком), радиомикрофон</li><li>Оборудование для фотосессии</li><li>Столы 180×70 — 4 шт, раскладные 80×80 — 6 шт, 20 стульев, 3 дивана, 3 кресла, барная стойка</li><li>Посуда на 20 персон и 20 стаканов, бокалы — отдельно</li><li>Уборная на 2 кабинки, холодильник с морозилкой, кулер, раковина, гардероб</li></ul></details>'+
    '<details><summary>Важно знать</summary><ul><li>В уличной обуви находиться запрещено, штраф 2 500 ₽</li><li>Мебель расставляете сами в тех. час и возвращаете на места после</li><li>Парковки нет, можно подъехать ко входу на разгрузку</li><li>Вторая половина оплаты и залог 50% от аренды — в день мероприятия до начала. Залог вернём на следующий день после проверки зала</li></ul></details>'+
    linesHtml(pr,true)+'<p class="err" id="o-err"></p><button class="cta" data-next2>Далее: контакты</button>';
}
function viewForm(){
  const pr=P.calc(S,order());
  return head(true)+bar()+'<h2>Подтвердите данные</h2>'+
    '<div class="summary"><div class="row"><span>'+(isEvt()?'Мероприятие':'Фото')+'</span><span>'+esc(hall(cs.hall).name)+' · '+esc(cs.format)+'</span></div><div class="row"><span>Когда</span><span class="num">'+fmtDate(cs.date)+'<br>'+span(cs.start,cs.hours)+'</span></div><div class="row"><span>Гостей</span><span class="num">'+cs.guests+'</span></div></div>'+
    linesHtml(pr,true)+
    '<label for="f-name">Фамилия и имя<input id="f-name" autocomplete="name" maxlength="100" value="'+esc(cs.name)+'"></label>'+
    '<label for="f-phone">Телефон<input id="f-phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="30" placeholder="+7 (___) ___-__-__" value="'+esc(cs.phone)+'"></label>'+
    '<label for="f-email">Email<input id="f-email" type="email" autocomplete="email" maxlength="120" value="'+esc(cs.email)+'"></label>'+
    '<label for="f-comment">Комментарий<textarea id="f-comment" maxlength="1000" placeholder="Пожелания, реквизит, тайминг">'+esc(cs.comment)+'</textarea></label>'+
    '<label class="check" for="f-agree1"><input id="f-agree1" type="checkbox"'+(cs.agree1?' checked':'')+'><span>Даю <a href="/consent" target="_blank">согласие на обработку персональных данных</a> и ознакомлен(а) с <a href="/privacy" target="_blank">Политикой обработки персональных данных</a></span></label>'+
    '<label class="check" for="f-agree2"><input id="f-agree2" type="checkbox"'+(cs.agree2?' checked':'')+'><span>Ознакомлен(а) и согласен(на) с <a href="/rules" target="_blank">Правилами студии</a>, включая условия отмены и возврата предоплаты</span></label>'+
    '<p class="note">После заявки у вас будет '+S.payMin+' минут, чтобы перевести предоплату и нажать «Я оплатил».</p>'+
    '<p class="err" id="f-err"></p><button class="cta" data-create'+(cs.busy?' disabled':'')+'>'+(cs.busy?'Отправляем…':'Отправить заявку')+'</button>';
}
function req(label,val,copy,mono){return '<div class="req"><div><small>'+label+'</small><b class="'+(mono?'mono num':'')+'">'+esc(val)+'</b></div>'+(copy?'<button class="copy" data-copy="'+esc(val)+'">Копировать</button>':'')+'</div>'}
function viewPay(b){
  const when='<div class="summary"><div class="row"><span>Заявка</span><span class="num">№'+b.id+'</span></div><div class="row"><span>'+(b.purpose==='event'?'Мероприятие':'Фото')+'</span><span>'+esc(hall(b.hall).name)+'</span></div><div class="row"><span>Когда</span><span class="num">'+fmtDate(b.date)+'<br>'+span(b.start,b.hours)+'</span></div><div class="row"><span>Итого</span><span class="num">'+rub(b.total)+'</span></div><div class="row"><span>Остаток на месте</span><span class="num">'+rub(b.total-b.prepay)+(b.deposit?' + залог '+rub(b.deposit):'')+'</span></div></div>';
  const tg=b.tgLink&&!b.tgLinked?'<a class="ghost tglink" href="'+esc(b.tgLink)+'" target="_blank" rel="noopener">Получать статус брони в Telegram</a>':'';
  if(b.status==='awaiting'&&b.pay){
    return head(false)+bar()+'<div><h2>Переведите предоплату</h2><p class="note">Заявка №'+b.id+' создана. После перевода нажмите кнопку внизу.</p></div>'+
      '<div class="pay"><div><small class="note">Сумма к переводу</small><div class="amount num">'+rub(b.prepay)+'</div></div>'+
      req('Номер карты',b.pay.card,true,true)+req('Или по СБП по номеру',b.pay.sbp,true,true)+req('Банк',b.pay.bank)+req('Получатель',b.pay.holder)+req('Комментарий к переводу','Бронь '+b.id,true)+'</div>'+
      '<div class="timer"><span>Время держится за вами до '+clock(b.deadline)+'</span><b class="num" data-deadline="'+b.deadline+'">'+left(b.deadline-nowMs())+'</b></div>'+
      when+'<button class="cta" data-paid'+(cs.busy?' disabled':'')+'>Я оплатил(а)</button>'+tg+'<button class="linkbtn" data-cancel>Отменить заявку</button>';
  }
  let box;
  if(b.status==='review')box='<div class="status review"><h2>Забронировано, но пока не подтверждено</h2><p>Время закреплено за вами. Администратор проверит поступление '+rub(b.prepay)+' и подтвердит бронь в течение '+S.confirmH+' часов. Эту страницу можно закрыть: ссылка на неё сохранена в адресе.</p></div>';
  else if(b.status==='confirmed')box='<div class="status confirmed"><h2>Забронировано</h2><p>Ждём вас '+fmtDate(b.date)+' в '+pad(hr(b.start))+':00'+(b.purpose==='event'?' (тех. час с '+pad(hr(b.start-b.pre))+':00)':'')+'. Предоплата '+rub(b.prepay)+' получена.'+(S.studio.address?' Адрес: '+esc(S.studio.address)+'.':'')+'</p></div>';
  else if(b.status==='expired')box='<div class="status bad"><h2>Время на оплату вышло</h2><p>Вы не нажали «Я оплатил» за '+S.payMin+' минут, время освободилось. Если вы уже перевели деньги, свяжитесь со студией'+(S.studio.phone?': '+esc(S.studio.phone):'')+'.</p></div>';
  else box='<div class="status bad"><h2>'+(b.status==='cancelled'?'Заявка отменена':'Оплата не найдена')+'</h2><p>'+(b.status==='cancelled'?'Время снова свободно.':'Администратор не нашёл перевод. Если вы оплатили, свяжитесь со студией'+(S.studio.phone?': '+esc(S.studio.phone):'')+'.')+'</p></div>';
  return head(false)+bar()+box+when+(['review','confirmed'].includes(b.status)?tg:'')+'<button class="ghost" data-new>Новая бронь</button>';
}

async function render(){
  try{
    let h;
    if(cs.step===1)h=viewPurpose();
    else if(cs.step===2){const m=ymd(cs.month).slice(0,7);h=viewDate(await loadMonth(m,cs.purpose))}
    else if(cs.step===3){await loadDay(cs.date);h=viewHall()}
    else if(cs.step===4){await loadDay(cs.date);h=viewTime()}
    else if(cs.step===5)h=viewOptions();
    else if(cs.step===6)h=viewForm();
    else h=viewPay(cs.booking);
    C.innerHTML=h;
  }catch(e){C.innerHTML=head(false)+'<div class="status bad"><h2>Не удалось загрузить</h2><p>'+esc(e.message)+'</p></div><button class="cta" data-retry>Повторить</button>';return}
  bind();
}
function bind(){
  if(cs.step===4){
    const gi=document.getElementById('f-guests');gi.addEventListener('change',()=>{cs.guests=Math.max(1,Math.min(hall(cs.hall).cap||S.maxGuests,+gi.value||1));render()});
    const fs=document.getElementById('f-format');fs.addEventListener('change',()=>{cs.format=fs.value});
  }
  if(cs.step===5){
    C.querySelectorAll('[data-clean]').forEach(el=>el.addEventListener('change',()=>{cs.evt.cleaning=+el.dataset.clean;render()}));
    const cy=C.querySelector('[data-cyc]');cy.addEventListener('change',()=>{cs.evt.cyc=cy.checked;render()});
    C.querySelectorAll('[data-extra]').forEach(el=>el.addEventListener('change',()=>{const id=el.dataset.extra;cs.evt.extras=el.checked?cs.evt.extras.concat(id):cs.evt.extras.filter(x=>x!==id);render()}));
  }
  if(cs.step===6){
    ['name','phone','email','comment'].forEach(k=>{const el=document.getElementById('f-'+k);el.addEventListener('input',()=>{cs[k]=el.value})});
    ['agree1','agree2'].forEach(k=>{const el=document.getElementById('f-'+k);el.addEventListener('change',()=>{cs[k]=el.checked})});
  }
}
function setPurpose(p){cs.purpose=p;cs.format='';if(p==='event'){cs.hall='all';cs.guests=Math.max(+cs.guests||0,20);cs.hours=Math.max(cs.hours,4)}else cs.evt={cleaning:0,tech:0,cyc:false,extras:[]}}
function goBack(){const o=ORDER[cs.purpose||'photo'];const i=o.indexOf(cs.step);cs.step=i>0?o[i-1]:1;render()}
function remember(b,token){try{localStorage.setItem('mp_last',JSON.stringify({id:b.id,t:token}))}catch(_){} history.replaceState(null,'','/?b='+b.id+'&t='+token)}

C.addEventListener('click',async e=>{
  const t=e.target.closest('button');if(!t||t.disabled)return;
  const d=t.dataset;
  if(d.retry!==undefined){render();return}
  if(d.occ){toast(d.occ==='confirmed'?'Это время уже забронировано':'Это время забронировано, но пока не подтверждено администратором');return}
  if(d.back!==undefined){goBack();return}
  if(d.purpose){setPurpose(d.purpose);if(d.purpose==='photo'){cs.hall=null;cs.guests=2;cs.hours=1}cs.step=2;render();return}
  if(d.mon){cs.month=new Date(cs.month.getFullYear(),cs.month.getMonth()+Number(d.mon),1);render();return}
  if(d.date){cs.date=d.date;cs.start=null;await loadDay(d.date,true);cs.step=isEvt()?4:3;if(!isEvt())cs.hall=null;render();return}
  if(d.hall){cs.hall=d.hall;cs.start=null;cs.hours=1;cs.step=4;render();return}
  if(d.mode){setPurpose(d.mode);cs.start=null;render();return}
  if(d.g){cs.guests=Math.max(1,Math.min(hall(cs.hall).cap||S.maxGuests,(+cs.guests||0)+Number(d.g)));render();return}
  if(d.slot){cs.start=+d.slot;if(!fitsCs(cs.start,cs.hours))cs.hours=minH();render();return}
  if(d.dur){cs.hours=Math.max(minH(),cs.hours+Number(d.dur));render();return}
  if(d.tech){const old=cs.evt.tech;cs.evt.tech=Math.max(0,Math.min(6,old+Number(d.tech)));if(!fitsCs(cs.start,cs.hours)){cs.evt.tech=old;toast('После мероприятия время уже занято')}render();return}
  if(d.next!==undefined){
    const err=document.getElementById('t-err');
    if(!(+cs.guests>0)){err.textContent='Укажите, сколько будет человек.';return}
    if(!cs.format){err.textContent=isEvt()?'Выберите формат мероприятия.':'Выберите формат съёмки.';return}
    cs.step=isEvt()?5:6;render();return;
  }
  if(d.next2!==undefined){if(!cs.evt.cleaning){document.getElementById('o-err').textContent='Выберите вариант клининга.';return}cs.step=6;render();return}
  if(d.create!==undefined){
    const err=document.getElementById('f-err');
    if(!cs.name.trim()){err.textContent='Укажите фамилию и имя.';return}
    const dg=cs.phone.replace(/\D/g,'');if(dg.length<10||dg.length>11){err.textContent='Укажите телефон: 10–11 цифр.';return}
    if(cs.email&&!/^\S+@\S+\.\S+$/.test(cs.email)){err.textContent='Проверьте email.';return}
    if(!cs.agree1||!cs.agree2){err.textContent='Отметьте оба согласия.';return}
    cs.busy=true;render();
    try{
      const j=await api('/api/bookings',{method:'POST',body:JSON.stringify(Object.assign(order(),{format:cs.format,name:cs.name,phone:cs.phone,email:cs.email,comment:cs.comment,agree1:true,agree2:true}))});
      cs.booking=j.booking;cs.token=j.token;cs.step=7;remember(j.booking,j.token);
    }catch(ex){
      if(ex.status===409){toast(ex.message);await loadDay(cs.date,true);cs.start=null;cs.step=4}
      else toast(ex.message);
    }
    cs.busy=false;render();return;
  }
  if(d.paid!==undefined){cs.busy=true;try{const j=await api('/api/bookings/'+cs.booking.id+'/paid?t='+cs.token,{method:'POST'});cs.booking=j.booking;toast('Время закреплено за вами до подтверждения')}catch(ex){toast(ex.message)}cs.busy=false;render();return}
  if(d.cancel!==undefined){try{const j=await api('/api/bookings/'+cs.booking.id+'/cancel?t='+cs.token,{method:'POST'});cs.booking=j.booking}catch(ex){toast(ex.message)}render();return}
  if(d.new!==undefined){cs=blank();history.replaceState(null,'','/');Object.keys(dayCache).forEach(k=>delete dayCache[k]);Object.keys(monthCache).forEach(k=>delete monthCache[k]);render();return}
  if(d.copy)copy(d.copy,t);
});
function copy(text,btn){
  const done=()=>{btn.textContent='Скопировано';setTimeout(()=>btn.textContent='Копировать',1400)};
  const fallback=()=>{const p=btn.previousElementSibling;const b=p&&(p.querySelector('b')||p);if(!b)return;const r=document.createRange();r.selectNodeContents(b);const s=getSelection();s.removeAllRanges();s.addRange(r);toast('Текст выделен, скопируйте вручную')};
  try{navigator.clipboard.writeText(text).then(done,fallback)}catch(_){fallback()}
}
let tt;function toast(s){const el=document.getElementById('toast');el.textContent=s;el.classList.add('show');clearTimeout(tt);tt=setTimeout(()=>el.classList.remove('show'),2600)}

/* таймер и обновление статуса заявки */
setInterval(()=>{document.querySelectorAll('[data-deadline]').forEach(el=>el.textContent=left(+el.dataset.deadline-nowMs()))},1000);
setInterval(async()=>{
  if(cs&&cs.step===7&&cs.booking&&['awaiting','review'].includes(cs.booking.status)){
    try{const j=await api('/api/bookings/'+cs.booking.id+'?t='+cs.token);if(j.booking.status!==cs.booking.status){cs.booking=j.booking;render()}else cs.booking=j.booking}catch(_){}
  }
},15000);

(async function init(){
  try{S=window.__CFG||await api('/api/config');skew=S.now-Date.now()}catch(e){C.innerHTML='<div class="status bad"><h2>Сервис временно недоступен</h2><p>Попробуйте обновить страницу через минуту.</p></div>';return}
  document.title='Бронь — '+S.studio.name;
  cs=blank();
  const q=new URLSearchParams(location.search);let id=q.get('b'),tok=q.get('t');
  if(!id){try{const l=JSON.parse(localStorage.getItem('mp_last')||'null');if(l&&q.get('resume')){id=l.id;tok=l.t}}catch(_){}}
  if(id&&tok){try{const j=await api('/api/bookings/'+id+'?t='+tok);cs.booking=j.booking;cs.token=tok;cs.purpose=j.booking.purpose;cs.step=7}catch(_){history.replaceState(null,'','/')}}
  render();
  /* пока клиент выбирает тип брони — расписание текущего месяца грузится в фоне */
  try{const m0=ymd(new Date()).slice(0,7);loadMonth(m0,'photo').catch(()=>{});loadMonth(m0,'event').catch(()=>{})}catch(_){}
})();
})();
