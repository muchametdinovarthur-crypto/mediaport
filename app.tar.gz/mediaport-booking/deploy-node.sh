#!/usr/bin/env bash
# Запуск МЕДИАПОРТ-брони БЕЗ Docker (на случай, если Docker Hub недоступен).
# Ставит Node.js 24 из nodejs.org и поднимает сервис через systemd на порту 80.
# Использование: bash deploy-node.sh ПАРОЛЬ_АДМИНА ПАРОЛЬ_ВЛАДЕЛЬЦА [URL]
set -e
ADMIN="$1"; OWNER="$2"
IP="$(hostname -I | awk '{print $1}')"
PUB="${3:-http://$IP}"
if [ -z "$ADMIN" ] || [ -z "$OWNER" ]; then
  echo "Укажите два пароля: bash deploy-node.sh ПАРОЛЬ_АДМИНА ПАРОЛЬ_ВЛАДЕЛЬЦА"
  exit 1
fi
APP="$(cd "$(dirname "$0")" && pwd)"
cd "$APP"

echo "== 1/5 Проверяю/ставлю Node.js 24 =="
NEED_NODE=1
if command -v node >/dev/null 2>&1; then
  MAJ="$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
  if [ "$MAJ" -ge 24 ] 2>/dev/null; then NEED_NODE=0; echo "Node уже есть: $(node -v)"; fi
fi
if [ "$NEED_NODE" = "1" ]; then
  BASE="https://nodejs.org/dist/latest-v24.x"
  FILE="$(curl -fsSL "$BASE/SHASUMS256.txt" | grep -oE 'node-v[0-9.]+-linux-x64\.tar\.gz' | head -1)"
  if [ -z "$FILE" ]; then echo "Не удалось узнать имя файла Node"; exit 1; fi
  echo "Скачиваю $FILE ..."
  curl -fsSL -o /tmp/node.tar.gz "$BASE/$FILE"
  rm -rf /opt/node && mkdir -p /opt/node
  tar -xzf /tmp/node.tar.gz -C /opt/node --strip-components=1
  ln -sf /opt/node/bin/node /usr/local/bin/node
  ln -sf /opt/node/bin/npm /usr/local/bin/npm
  echo "Поставлен Node $(/usr/local/bin/node -v)"
fi
NODE_BIN="$(command -v node)"

echo "== 2/5 Готовлю папку данных =="
mkdir -p "$APP/data/backups"

echo "== 3/5 Пишу сервис systemd =="
SECRET="$(/usr/local/bin/node -e 'console.log(require("crypto").randomBytes(32).toString("hex"))' 2>/dev/null || date +%s%N)"
cat > /etc/systemd/system/mediaport.service <<UNIT
[Unit]
Description=MEDIAPORT booking
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP
Environment=PORT=80
Environment=TZ=Europe/Moscow
Environment=DATA_DIR=$APP/data
Environment=ADMIN_PASSWORD=$ADMIN
Environment=OWNER_PASSWORD=$OWNER
Environment=SESSION_SECRET=$SECRET
Environment=PUBLIC_URL=$PUB
ExecStart=$NODE_BIN --no-warnings server/index.js
Restart=always
RestartSec=3
User=root

[Install]
WantedBy=multi-user.target
UNIT

echo "== 4/5 Запускаю сервис =="
systemctl daemon-reload
systemctl enable mediaport >/dev/null 2>&1 || true
systemctl restart mediaport
command -v ufw >/dev/null 2>&1 && ufw allow 80 >/dev/null 2>&1 || true
sleep 2

echo "== 5/5 Статус =="
systemctl --no-pager --full status mediaport | head -12 || true
echo "----------------------------------------"
echo "ГОТОВО. Сайт:   $PUB"
echo "Админка:        $PUB/admin"
echo "----------------------------------------"
