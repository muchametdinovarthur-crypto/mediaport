'use strict';
/* Онлайн-бронь Лофт МЕДИАПОРТ — сервер без внешних зависимостей (Node.js 22+, встроенный SQLite). */
process.env.TZ = process.env.TZ || 'Europe/Moscow';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const { DatabaseSync } = require('node:sqlite');
const P = require('../public/pricing.js');
const DEFAULTS = require('./defaults.js');

const PORT = +process.env.PORT || 3000;
const ROOT = path.join(__dirname, '..');
const PUBLIC = path.join(ROOT, 'public');
const DATA = process.env.DATA_DIR || path.join(ROOT, 'data');
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const OWNER_PASSWORD = process.env.OWNER_PASSWORD || '';  /* владелец: только просмотр, отдельный пароль */
const SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const TG_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const TG_ADMINS = (process.env.TELEGRAM_ADMIN_CHAT_IDS || '').split(',').map(s => s.trim()).filter(Boolean);
const PUBLIC_URL = (process.env.PUBLIC_URL || 'http://localhost:' + PORT).replace(/\/$/, '');
const ACTIVE = ['awaiting', 'review', 'confirmed', 'blocked'];
const ST = { awaiting: 'ждёт оплату', review: 'забронировано, не подтверждено', confirmed: 'забронировано', blocked: 'закрыто', rejected: 'отклонена', cancelled: 'отменена', expired: 'не оплачена вовремя' };

if (!ADMIN_PASSWORD) console.warn('ВНИМАНИЕ: не задан ADMIN_PASSWORD — вход в админку невозможен.');
fs.mkdirSync(path.join(DATA, 'backups'), { recursive: true });

/* ---------- база ---------- */
const db = new DatabaseSync(path.join(DATA, 'booking.sqlite'));
db.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS bookings(
  id INTEGER PRIMARY KEY AUTOINCREMENT, token TEXT, hall TEXT, date TEXT, start INTEGER, hours INTEGER, pre INTEGER DEFAULT 0, post INTEGER DEFAULT 0,
  purpose TEXT, format TEXT, guests INTEGER, evt TEXT, discount INTEGER DEFAULT 0, lines TEXT, total INTEGER, prepay INTEGER, deposit INTEGER DEFAULT 0,
  name TEXT, phone TEXT, email TEXT, comment TEXT, status TEXT, source TEXT, note TEXT DEFAULT '', full_paid INTEGER DEFAULT 0, deposit_state TEXT DEFAULT 'none',
  overdue INTEGER DEFAULT 0, reason TEXT, created_at INTEGER, paid_at INTEGER, confirmed_at INTEGER, consent TEXT, history TEXT, tg_chat TEXT);
CREATE INDEX IF NOT EXISTS bookings_date ON bookings(date);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS feed(id INTEGER PRIMARY KEY AUTOINCREMENT, t INTEGER, text TEXT);`);
if (!db.prepare("SELECT 1 FROM sqlite_sequence WHERE name='bookings'").get() && !db.prepare('SELECT 1 FROM bookings').get())
  db.prepare("INSERT INTO sqlite_sequence(name,seq) VALUES('bookings',1000)").run();

function getSettings() {
  const r = db.prepare("SELECT value FROM settings WHERE key='main'").get();
  return Object.assign({}, DEFAULTS, r ? JSON.parse(r.value) : {});
}
function saveSettings(s) { db.prepare("INSERT INTO settings(key,value) VALUES('main',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(JSON.stringify(s)); }
let S = getSettings();

const J = ['evt', 'lines', 'consent', 'history'];
function row2b(r) { if (!r) return null; const b = Object.assign({}, r); J.forEach(k => { b[k] = r[k] ? JSON.parse(r[k]) : (k === 'history' || k === 'lines' ? [] : null); }); b.full_paid = !!r.full_paid; b.overdue = !!r.overdue; return b; }
const getB = id => row2b(db.prepare('SELECT * FROM bookings WHERE id=?').get(id));
function saveB(b) {
  const cols = ['token','hall','date','start','hours','pre','post','purpose','format','guests','evt','discount','lines','total','prepay','deposit','name','phone','email','comment','status','source','note','full_paid','deposit_state','overdue','reason','created_at','paid_at','confirmed_at','consent','history','tg_chat'];
  const vals = cols.map(c => J.includes(c) ? JSON.stringify(b[c] == null ? (c === 'history' || c === 'lines' ? [] : null) : b[c]) : (typeof b[c] === 'boolean' ? (b[c] ? 1 : 0) : (b[c] === undefined ? null : b[c])));
  if (b.id) { db.prepare('UPDATE bookings SET ' + cols.map(c => c + '=?').join(',') + ' WHERE id=?').run(...vals, b.id); return b; }
  const r = db.prepare('INSERT INTO bookings(' + cols.join(',') + ') VALUES(' + cols.map(() => '?').join(',') + ')').run(...vals);
  b.id = Number(r.lastInsertRowid); return b;
}
function hist(b, text) { (b.history = b.history || []).push({ t: Date.now(), text }); }
function log(text) { db.prepare('INSERT INTO feed(t,text) VALUES(?,?)').run(Date.now(), text); }

/* ---------- время и занятость ---------- */
const todayStr = () => P.ymd(new Date());
function slotTime(date, i) { const d = P.parse(date); d.setHours(6 + i, 0, 0, 0); return d.getTime(); }
const span = (s, h) => P.pad(P.hr(s)) + ':00–' + P.pad(P.hr(s + h)) + ':00';
const fmtDate = s => { const d = P.parse(s); return d.getDate() + ' ' + ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'][d.getMonth()] + ', ' + ['вс','пн','вт','ср','чт','пт','сб'][d.getDay()]; };
const hallName = id => (S.halls.find(h => h.id === id) || {}).name || id;
function busyFor(date, excludeId) {
  return db.prepare("SELECT id,hall,start,hours,pre,post,status FROM bookings WHERE date=? AND status IN ('awaiting','review','confirmed','blocked')").all(date)
    .filter(r => r.id !== excludeId).map(r => ({ id: r.id, hall: r.hall, start: r.start - r.pre, end: r.start + r.hours + r.post, own: r.start, status: r.status }));
}
/* прошедшие часы — тоже «занято» для проверки */
function withPast(date, busy) {
  const now = Date.now(), out = busy.slice();
  for (let i = 0; i < 24; i++) if (slotTime(date, i) < now) out.push({ hall: 'all', start: i, end: i + 1, status: 'past' });
  return out;
}
const deadline = b => b.status === 'review' ? (b.paid_at || 0) + S.confirmH * 3600000 : b.created_at + S.payMin * 60000;

/* ---------- Telegram ---------- */
let botName = '';
async function tg(method, params) {
  if (!TG_TOKEN) return null;
  try {
    const r = await fetch('https://api.telegram.org/bot' + TG_TOKEN + '/' + method, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(params || {}) });
    const j = await r.json(); if (!j.ok) console.warn('telegram', method, j.description); return j.result;
  } catch (e) { console.warn('telegram', method, e.message); return null; }
}
const escH = s => String(s == null ? '' : s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
function notifyAdmins(html, buttons) {
  TG_ADMINS.forEach(chat => tg('sendMessage', { chat_id: chat, text: html, parse_mode: 'HTML', disable_web_page_preview: true, reply_markup: buttons ? { inline_keyboard: buttons } : undefined }));
}
function notifyClient(b, text) { if (b.tg_chat) tg('sendMessage', { chat_id: b.tg_chat, text, parse_mode: 'HTML' }); }
const bLine = b => '№' + b.id + ' · ' + hallName(b.hall) + (b.purpose === 'event' ? ' (мероприятие)' : '') + ' · ' + fmtDate(b.date) + ', ' + span(b.start, b.hours);
const adminLink = () => '\n<a href="' + PUBLIC_URL + '/admin">Открыть админку</a>';

function todaySummary() {
  const t = todayStr();
  const rows = db.prepare("SELECT * FROM bookings WHERE date=? AND status IN ('confirmed','review','awaiting') ORDER BY start").all(t).map(row2b);
  const rev = db.prepare("SELECT count(*) n FROM bookings WHERE status='review'").get().n;
  let s = '<b>Сегодня, ' + fmtDate(t) + '</b>\n';
  s += rows.length ? rows.map(b => span(b.start, b.hours) + ' — ' + hallName(b.hall) + ', ' + escH(b.name) + ', ' + b.guests + ' чел.' + (b.status === 'confirmed' && !b.full_paid ? ' · доплата ' + P.rub(b.total - b.prepay) : '') + (b.status !== 'confirmed' ? ' · ' + ST[b.status] : '')).join('\n') : 'Броней нет.';
  if (rev) s += '\n\nЖдут подтверждения оплаты: ' + rev;
  return s + adminLink();
}

async function botLoop() {
  if (!TG_TOKEN) return;
  const me = await tg('getMe'); botName = me ? me.username : '';
  let offset = 0;
  for (;;) {
    let ups = null;
    try {
      const r = await fetch('https://api.telegram.org/bot' + TG_TOKEN + '/getUpdates', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ offset, timeout: 25, allowed_updates: ['message', 'callback_query'] }) });
      const j = await r.json();
      if (!j.ok) { console.warn('telegram getUpdates', j.description); await new Promise(r => setTimeout(r, 30000)); continue; }
      ups = j.result;
    } catch (e) { await new Promise(r => setTimeout(r, 5000)); continue; }
    for (const u of ups) {
      offset = u.update_id + 1;
      try { await handleUpdate(u); } catch (e) { console.warn('bot', e.message); }
    }
  }
}
async function handleUpdate(u) {
  if (u.message && u.message.text) {
    const chat = String(u.message.chat.id), text = u.message.text.trim(), isAdmin = TG_ADMINS.includes(chat);
    const m = text.match(/^\/start\s+b(\d+)_([a-f0-9]{32})$/);
    if (m) {
      const b = getB(+m[1]);
      if (b && b.token === m[2]) { b.tg_chat = chat; hist(b, 'Клиент подключил уведомления в Telegram'); saveB(b); return tg('sendMessage', { chat_id: chat, text: 'Готово. Будем присылать сюда статус брони №' + b.id + ' (' + fmtDate(b.date) + ', ' + span(b.start, b.hours) + ').' }); }
      return tg('sendMessage', { chat_id: chat, text: 'Не нашли такую бронь. Проверьте ссылку.' });
    }
    if (text === '/today' && isAdmin) return tg('sendMessage', { chat_id: chat, text: todaySummary(), parse_mode: 'HTML' });
    if (text.startsWith('/start')) {
      return tg('sendMessage', { chat_id: chat, parse_mode: 'HTML', text: isAdmin
        ? 'Вы администратор. Сюда приходят новые заявки и оплаты. Команда /today — брони на сегодня.' + adminLink()
        : 'Здравствуйте! Забронировать студию: ' + PUBLIC_URL + '\n\nВаш chat ID: <code>' + chat + '</code> (нужен, только если вы администратор).' });
    }
  }
  if (u.callback_query) {
    const q = u.callback_query, chat = String(q.message.chat.id);
    if (!TG_ADMINS.includes(chat)) return tg('answerCallbackQuery', { callback_query_id: q.id, text: 'Нет доступа' });
    const [act, id] = String(q.data).split(':');
    const b = getB(+id);
    let res = 'Бронь не найдена';
    if (b) {
      if (b.status !== 'review' && b.status !== 'awaiting') res = 'Уже обработана: ' + ST[b.status];
      else if (act === 'c') { applyAction(b, 'confirm', {}, 'Telegram'); res = '✓ Подтверждена'; }
      else if (act === 'r') { applyAction(b, 'reject', {}, 'Telegram'); res = '✗ Отклонена'; }
    }
    await tg('answerCallbackQuery', { callback_query_id: q.id, text: res });
    await tg('editMessageText', { chat_id: chat, message_id: q.message.message_id, text: (q.message.text || '') + '\n\n' + res, disable_web_page_preview: true });
  }
}

/* ---------- действия с бронью ---------- */
function applyAction(b, action, body, who) {
  const by = who ? ' (' + who + ')' : '';
  switch (action) {
    case 'confirm':
      if (!['review', 'awaiting'].includes(b.status)) throw httpErr(409, 'Бронь уже обработана');
      b.status = 'confirmed'; b.confirmed_at = Date.now(); b.paid_at = b.paid_at || Date.now(); b.overdue = false;
      hist(b, 'Администратор подтвердил предоплату' + by); log('Подтверждена бронь ' + bLine(b) + by);
      notifyClient(b, '✅ Бронь №' + b.id + ' подтверждена: ' + hallName(b.hall) + ', ' + fmtDate(b.date) + ', ' + span(b.start, b.hours) + '. Остаток ' + P.rub(b.total - b.prepay) + ' оплачивается на месте.');
      break;
    case 'reject':
      if (!['review', 'awaiting'].includes(b.status)) throw httpErr(409, 'Бронь уже обработана');
      b.status = 'rejected'; hist(b, 'Отклонена: перевод не найден' + by); log('Отклонена бронь ' + bLine(b) + by);
      notifyClient(b, 'Бронь №' + b.id + ': администратор не нашёл перевод. Если вы оплатили, пришлите чек в Telegram студии.');
      break;
    case 'full':
      if (b.status !== 'confirmed') throw httpErr(409, 'Бронь не подтверждена');
      b.full_paid = true; hist(b, 'Доплата ' + P.rub(b.total - b.prepay) + ' получена'); log('Доплата получена: ' + bLine(b)); break;
    case 'depin': b.deposit_state = 'held'; hist(b, 'Залог ' + P.rub(b.deposit) + ' получен'); break;
    case 'depout': b.deposit_state = 'returned'; hist(b, 'Залог ' + P.rub(b.deposit) + ' возвращён'); log('Залог возвращён: ' + bLine(b)); break;
    case 'remind':
      hist(b, 'Клиенту отправлено напоминание об оплате');
      notifyClient(b, 'Напоминаем: для брони №' + b.id + ' нужно перевести предоплату ' + P.rub(b.prepay) + '. Реквизиты: ' + PUBLIC_URL + '/?b=' + b.id + '&t=' + b.token);
      break;
    case 'note': b.note = String(body.note || '').slice(0, 2000); break;
    case 'cancel': {
      if (!ACTIVE.includes(b.status)) throw httpErr(409, 'Бронь уже не активна');
      const r = String(body.reason || 'Другое').slice(0, 100);
      const wasBlocked = b.status === 'blocked';
      b.status = 'cancelled'; hist(b, (wasBlocked ? 'Время открыто' : 'Отменена: ' + r.toLowerCase()) + by); log('Отменена бронь ' + bLine(b) + ' (' + r.toLowerCase() + ')');
      notifyClient(b, 'Бронь №' + b.id + ' отменена. Если это ошибка, свяжитесь со студией.');
      break;
    }
    case 'move': {
      if (!['awaiting', 'review', 'confirmed'].includes(b.status)) throw httpErr(409, 'Эту бронь нельзя перенести');
      const date = String(body.date || ''), start = +body.start, hours = +body.hours;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !(start >= 0 && start < 24) || !(hours >= 1)) throw httpErr(400, 'Проверьте дату и время');
      if (b.purpose === 'event' && hours < 4) throw httpErr(400, 'Мероприятие — от 4 часов');
      if (!P.fits(withPast(date, busyFor(date, b.id)), b.hall, start, hours, b.pre, b.post)) throw httpErr(409, 'Это время занято или уже прошло');
      const was = fmtDate(b.date) + ', ' + span(b.start, b.hours);
      Object.assign(b, { date, start, hours });
      const pr = P.calc(S, b); b.lines = pr.lines; b.total = pr.total; b.deposit = pr.deposit; if (b.status === 'awaiting') b.prepay = pr.prepay;
      hist(b, 'Перенесена с ' + was + ' на ' + fmtDate(date) + ', ' + span(start, hours)); log('Перенесена бронь ' + bLine(b));
      notifyClient(b, 'Бронь №' + b.id + ' перенесена на ' + fmtDate(date) + ', ' + span(start, hours) + '.');
      break;
    }
    default: throw httpErr(400, 'Неизвестное действие');
  }
  saveB(b); return b;
}

/* ---------- валидация заявки ---------- */
function validateOrder(o, admin) {
  const err = m => { throw httpErr(400, m); };
  const purpose = o.purpose === 'event' ? 'event' : 'photo';
  const hall = S.halls.find(h => h.id === o.hall); if (!hall) err('Выберите локацию');
  if (purpose === 'event' && hall.id !== 'all') err('Мероприятие — только весь зал');
  const date = String(o.date || ''); if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) err('Неверная дата');
  const days = Math.round((P.parse(date) - P.parse(todayStr())) / 86400000);
  if (days < 0 || (!admin && days > (S.maxDaysAhead || 92))) err('На эту дату бронь недоступна');
  const start = Math.floor(+o.start), hours = Math.floor(+o.hours);
  if (!(start >= 0 && start <= 23)) err('Неверное время');
  if (!(hours >= (purpose === 'event' ? 4 : 1) && hours <= 24)) err(purpose === 'event' ? 'Мероприятие — от 4 часов' : 'Минимум 1 час');
  const guests = Math.floor(+o.guests); if (!(guests >= 1 && guests <= (hall.cap || S.maxGuests))) err('Укажите число гостей');
  const formats = purpose === 'event' ? S.eventFormats : S.photoFormats;
  const format = String(o.format || ''); if (!formats.includes(format)) err('Выберите формат');
  let evt = null;
  if (purpose === 'event') {
    const e = o.evt || {};
    const cleaning = +e.cleaning; if (!S.cleaning.some(c => c.price === cleaning)) err('Выберите клининг');
    const tech = Math.max(0, Math.min(6, Math.floor(+e.tech || 0)));
    const extras = Array.isArray(e.extras) ? e.extras.filter(id => S.extras.some(x => x.id === id)) : [];
    evt = { cleaning, tech, cyc: !!e.cyc, extras };
  }
  const name = String(o.name || '').trim().slice(0, 100); if (!name) err('Укажите имя');
  const phone = String(o.phone || '').trim().slice(0, 30); const dg = phone.replace(/\D/g, ''); if (dg.length < 10 || dg.length > 11) err('Укажите телефон: 10–11 цифр');
  const email = String(o.email || '').trim().slice(0, 120); if (email && !/^\S+@\S+\.\S+$/.test(email)) err('Проверьте email');
  const comment = String(o.comment || '').trim().slice(0, 1000);
  const discount = admin ? Math.max(0, Math.floor(+o.discount || 0)) : 0;
  const [pre, post] = P.prePost(purpose, evt && evt.tech);
  return { purpose, hall: hall.id, date, start, hours, guests, format, evt, name, phone, email, comment, discount, pre, post };
}
function createBooking(o, extra) {
  db.exec('BEGIN IMMEDIATE');
  try {
    if (!P.fits(withPast(o.date, busyFor(o.date)), o.hall, o.start, o.hours, o.pre, o.post)) throw httpErr(409, 'Это время только что заняли. Выберите другое.');
    const pr = P.calc(S, o);
    const b = Object.assign({ token: crypto.randomBytes(16).toString('hex'), lines: pr.lines, total: pr.total, prepay: pr.prepay, deposit: pr.deposit, note: '', full_paid: false, deposit_state: 'none', overdue: false, created_at: Date.now(), history: [] }, o, extra);
    saveB(b); db.exec('COMMIT'); return b;
  } catch (e) { db.exec('ROLLBACK'); throw e; }
}

/* ---------- публичные данные ---------- */
function publicSettings() {
  return { halls: S.halls, eventTiers: S.eventTiers, cleaning: S.cleaning, extras: S.extras, photoFormats: S.photoFormats, eventFormats: S.eventFormats,
    prepay: S.prepay, payMin: S.payMin, confirmH: S.confirmH, nightK: S.nightK, guestFree: S.guestFree, guestFee: S.guestFee, techFee: S.techFee, cycFee: S.cycFee,
    maxGuests: S.maxGuests, maxDaysAhead: S.maxDaysAhead, studio: S.studio, botName, today: todayStr(), now: Date.now() };
}
function clientView(b) {
  return { id: b.id, status: b.status, overdue: b.overdue, hall: b.hall, date: b.date, start: b.start, hours: b.hours, pre: b.pre, post: b.post, purpose: b.purpose, format: b.format, guests: b.guests,
    lines: b.lines, total: b.total, prepay: b.prepay, deposit: b.deposit, deadline: deadline(b), tgLinked: !!b.tg_chat,
    pay: b.status === 'awaiting' ? S.pay : null, tgLink: botName ? 'https://t.me/' + botName + '?start=b' + b.id + '_' + b.token : null };
}
function monthStatus(month, purpose) {
  const [y, m] = month.split('-').map(Number); const days = new Date(y, m, 0).getDate(); const out = {};
  for (let d = 1; d <= days; d++) {
    const date = month + '-' + P.pad(d); if (date < todayStr()) continue;
    const busy = withPast(date, busyFor(date)); let free = false;
    if (purpose === 'event') { for (let i = 1; i < 24 && !free; i++) if (P.fits(busy, 'all', i, 4, 1, 1)) free = true; }
    else { for (const h of S.halls) { for (let i = 0; i < 24 && !free; i++) if (P.fits(busy, h.id, i, 1, 0, 0)) free = true; if (free) break; } }
    out[date] = free ? 'free' : 'full';
  }
  return out;
}

/* ---------- сессия админа ---------- */
const sign = v => crypto.createHmac('sha256', SECRET).update(v).digest('hex');
const pwEq = (a, b) => !!a && !!b && a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
function makeSession(role) { const exp = Date.now() + 30 * 86400000; return exp + '.' + role + '.' + sign(exp + '.' + role); }
function roleOf(req) {
  const c = (req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith('mp_admin='));
  if (!c) return null; const parts = c.slice(9).split('.'); if (parts.length !== 3) return null;
  const [exp, role, sig] = parts;
  if (+exp < Date.now() || !['admin', 'owner'].includes(role)) return null;
  const good = sign(exp + '.' + role);
  return sig.length === good.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good)) ? role : null;
}
const hits = new Map();
function limited(key, max, ms) { const n = Date.now(); const a = (hits.get(key) || []).filter(t => n - t < ms); a.push(n); hits.set(key, a); return a.length > max; }

/* ---------- HTTP ---------- */
function httpErr(code, message) { const e = new Error(message); e.code = code; return e; }
function send(res, code, obj, headers, req) {
  const body = Buffer.from(JSON.stringify(obj));
  const h = Object.assign({ 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'vary': 'accept-encoding' }, headers || {});
  if (req && h.etag && req.headers['if-none-match'] === h.etag) { h['cache-control'] = 'no-cache'; res.writeHead(304, h); return res.end(); }
  if (body.length > 1024 && req && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) {
    const z = zlib.gzipSync(body, { level: 6 }); h['content-encoding'] = 'gzip'; h['content-length'] = z.length; res.writeHead(code, h); return res.end(z);
  }
  h['content-length'] = body.length; res.writeHead(code, h); res.end(body);
}
function readBody(req) {
  return new Promise((ok, fail) => { let s = ''; req.on('data', c => { s += c; if (s.length > 100000) { fail(httpErr(413, 'Слишком большой запрос')); req.destroy(); } }); req.on('end', () => { try { ok(s ? JSON.parse(s) : {}); } catch (e) { fail(httpErr(400, 'Неверный JSON')); } }); });
}
const ip = req => (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.jpg': 'image/jpeg', '.png': 'image/png', '.svg': 'image/svg+xml', '.md': 'text/markdown; charset=utf-8', '.ico': 'image/x-icon', '.webp': 'image/webp' };
const PAGES = { '/': 'index.html', '/admin': 'admin.html', '/privacy': 'legal.html', '/consent': 'legal.html', '/rules': 'legal.html' };
/* версия ресурсов: меняется при каждом обновлении файлов, браузер тогда берёт свежие скрипты */
function assetVersion() {
  const h = crypto.createHash('md5');
  (function walk(d) { fs.readdirSync(d).sort().forEach(f => { const q = path.join(d, f), st = fs.statSync(q); if (st.isDirectory()) walk(q); else h.update(f + st.size + st.mtimeMs); }); })(PUBLIC);
  return h.digest('hex').slice(0, 8);
}
const ASSET_V = assetVersion();
const fileCache = new Map();
function serveStatic(req, res, pathname) {
  const rel = PAGES[pathname] || pathname.replace(/^\/+/, '');
  const file = path.normalize(path.join(PUBLIC, rel));
  if (!file.startsWith(PUBLIC)) return send(res, 404, { error: 'Не найдено' });
  let st; try { st = fs.statSync(file); if (!st.isFile()) throw 0; } catch (e) { res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }); return res.end('Страница не найдена'); }
  const ext = path.extname(file), isHtml = ext === '.html';
  let c = fileCache.get(file);
  if (!c || c.mtime !== st.mtimeMs) {
    let buf = fs.readFileSync(file);
    if (isHtml) buf = Buffer.from(buf.toString('utf8').replace(/((?:src|href)="\/[\w.\-]+\.(?:js|css))"/g, '$1?v=' + ASSET_V + '"'));
    const compress = /^(\.html|\.js|\.css|\.md|\.svg)$/.test(ext) && buf.length > 512;
    c = { mtime: st.mtimeMs, buf, gz: compress ? zlib.gzipSync(buf, { level: 9 }) : null, etag: '"' + crypto.createHash('md5').update(buf).digest('hex').slice(0, 16) + '"' };
    fileCache.set(file, c);
  }
  const h = { 'content-type': MIME[ext] || 'application/octet-stream', 'vary': 'accept-encoding', 'x-content-type-options': 'nosniff', 'referrer-policy': 'same-origin', 'x-frame-options': pathname === '/admin' ? 'DENY' : 'SAMEORIGIN' };
  let body = c.buf;
  if (pathname === '/') {            /* настройки вшиваем в страницу: на один запрос меньше до первого экрана */
    body = Buffer.from(c.buf.toString('utf8').replace('<!--CFG-->', '<script>window.__CFG=' + JSON.stringify(publicSettings()).replace(/</g, '\\u003c') + '</script>'));
    h['cache-control'] = 'no-store';
  } else {
    h['cache-control'] = isHtml ? 'no-cache' : (/[?&]v=/.test(req.url) ? 'public, max-age=31536000, immutable' : /^\.(jpg|png|webp|ico)$/.test(ext) ? 'public, max-age=604800' : 'public, max-age=86400');
    h.etag = c.etag;
    if (req.headers['if-none-match'] === c.etag) { res.writeHead(304, h); return res.end(); }
    if (c.gz && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) { h['content-encoding'] = 'gzip'; body = c.gz; }
  }
  if (pathname === '/' && body.length > 512 && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) { body = zlib.gzipSync(body); h['content-encoding'] = 'gzip'; }
  h['content-length'] = body.length;
  res.writeHead(200, h);
  res.end(req.method === 'HEAD' ? undefined : body);
}

async function api(req, res, url) {
  const p = url.pathname, m = req.method;
  /* публичное */
  if (m === 'GET' && p === '/api/config') return send(res, 200, publicSettings(), null, req);
  if (m === 'GET' && p === '/api/month') {
    const month = url.searchParams.get('month') || ''; if (!/^\d{4}-\d{2}$/.test(month)) throw httpErr(400, 'Неверный месяц');
    return send(res, 200, { days: monthStatus(month, url.searchParams.get('purpose')) });
  }
  if (m === 'GET' && p === '/api/day') {
    const date = url.searchParams.get('date') || ''; if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw httpErr(400, 'Неверная дата');
    return send(res, 200, { busy: busyFor(date).map(x => ({ hall: x.hall, start: x.start, end: x.end, own: x.own, status: x.status === 'blocked' ? 'confirmed' : x.status === 'awaiting' ? 'review' : x.status })), now: Date.now() });
  }
  if (m === 'POST' && p === '/api/bookings') {
    if (limited('book:' + ip(req), 15, 3600000)) throw httpErr(429, 'Слишком много заявок. Попробуйте позже или позвоните в студию.');
    const body = await readBody(req);
    if (!body.agree1 || !body.agree2) throw httpErr(400, 'Отметьте оба согласия');
    const o = validateOrder(body, false);
    const b = createBooking(o, { status: 'awaiting', source: 'online', consent: { at: Date.now(), ip: ip(req), ua: String(req.headers['user-agent'] || '').slice(0, 300), version: S.consentVersion || '1' }, history: [{ t: Date.now(), text: 'Заявка с сайта' }] });
    log('Новая заявка ' + bLine(b) + ', ' + b.name);
    notifyAdmins('🆕 <b>Новая заявка</b>\n' + bLine(b) + '\n' + escH(b.name) + ', ' + escH(b.phone) + '\n' + b.guests + ' чел. · ' + escH(b.format) + '\nИтого ' + P.rub(b.total) + ', ждём предоплату ' + P.rub(b.prepay) + ' (' + S.payMin + ' мин).');
    return send(res, 201, { booking: clientView(b), token: b.token });
  }
  let mm = p.match(/^\/api\/bookings\/(\d+)(\/paid|\/cancel)?$/);
  if (mm) {
    const b = getB(+mm[1]); const token = url.searchParams.get('t') || '';
    if (!b || !b.token || token.length !== b.token.length || !crypto.timingSafeEqual(Buffer.from(token), Buffer.from(b.token))) throw httpErr(404, 'Бронь не найдена');
    if (m === 'GET' && !mm[2]) return send(res, 200, { booking: clientView(b) });
    if (m === 'POST' && mm[2] === '/paid') {
      if (b.status !== 'awaiting') return send(res, 200, { booking: clientView(b) });
      b.status = 'review'; b.paid_at = Date.now(); hist(b, 'Клиент нажал «Я оплатил»'); saveB(b);
      log('Клиент нажал «Я оплатил»: ' + bLine(b));
      notifyAdmins('💳 <b>Клиент нажал «Я оплатил»</b>\n' + bLine(b) + '\n' + escH(b.name) + ', ' + escH(b.phone) + '\nПроверьте поступление <b>' + P.rub(b.prepay) + '</b> (комментарий «Бронь ' + b.id + '»). Подтвердить нужно за ' + S.confirmH + ' ч.',
        [[{ text: '✅ Деньги пришли', callback_data: 'c:' + b.id }, { text: '✗ Перевода нет', callback_data: 'r:' + b.id }]]);
      return send(res, 200, { booking: clientView(b) });
    }
    if (m === 'POST' && mm[2] === '/cancel') {
      if (b.status !== 'awaiting') throw httpErr(409, 'Эту заявку можно отменить только через студию');
      b.status = 'cancelled'; hist(b, 'Клиент отменил заявку'); saveB(b); log('Клиент отменил заявку ' + bLine(b));
      return send(res, 200, { booking: clientView(b) });
    }
  }
  /* админ */
  if (m === 'POST' && p === '/api/admin/login') {
    if (limited('login:' + ip(req), 10, 900000)) throw httpErr(429, 'Слишком много попыток. Подождите 15 минут.');
    const body = await readBody(req); const pw = String(body.password || '');
    const role = pwEq(pw, ADMIN_PASSWORD) ? 'admin' : pwEq(pw, OWNER_PASSWORD) ? 'owner' : null;
    if (!role) throw httpErr(401, 'Неверный пароль');
    const secure = (req.headers['x-forwarded-proto'] || '').includes('https') ? '; Secure' : '';
    return send(res, 200, { ok: true, role }, { 'set-cookie': 'mp_admin=' + makeSession(role) + '; HttpOnly; SameSite=Strict; Path=/; Max-Age=' + 30 * 86400 + secure });
  }
  if (m === 'POST' && p === '/api/admin/logout') return send(res, 200, { ok: true }, { 'set-cookie': 'mp_admin=; Path=/; Max-Age=0' });
  if (p.startsWith('/api/admin/')) {
    const role = roleOf(req);
    if (!role) throw httpErr(401, 'Войдите в админку');
    if (m !== 'GET' && role !== 'admin') throw httpErr(403, 'У вас доступ только для просмотра');
    if (m === 'GET' && p === '/api/admin/state') {
      const since = P.ymd(new Date(Date.now() - 400 * 86400000));
      const bookings = db.prepare('SELECT * FROM bookings WHERE date>=? ORDER BY date,start').all(since).map(row2b).map(b => { delete b.token; return b; });
      const feed = db.prepare('SELECT t,text FROM feed ORDER BY id DESC LIMIT 40').all();
      return send(res, 200, { role, bookings, feed, settings: S, now: Date.now(), today: todayStr(), telegram: { enabled: !!TG_TOKEN, admins: TG_ADMINS.length, botName } }, null, req);
    }
    if (m === 'POST' && p === '/api/admin/bookings') {
      const body = await readBody(req);
      if (body.kind === 'block') {
        const hall = S.halls.find(h => h.id === body.hall); const date = String(body.date || ''), start = +body.start, hours = +body.hours;
        if (!hall || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !(start >= 0 && start < 24) || !(hours >= 1)) throw httpErr(400, 'Проверьте данные');
        const b = createBooking({ hall: hall.id, date, start, hours, pre: 0, post: 0, purpose: 'photo', format: '', guests: 0, evt: null, name: 'Закрыто', phone: '', email: '', comment: '', discount: 0 },
          { status: 'blocked', source: 'admin', reason: String(body.reason || 'Без причины').slice(0, 200), lines: [], total: 0, prepay: 0, deposit: 0, history: [{ t: Date.now(), text: 'Время закрыто администратором' }] });
        log('Время закрыто: ' + hallName(b.hall) + ', ' + fmtDate(b.date) + ', ' + span(b.start, b.hours));
        return send(res, 201, { booking: b });
      }
      const o = validateOrder(body, true);
      const pay = body.pay === 'awaiting' ? 'awaiting' : body.pay === 'full' ? 'full' : 'prepaid';
      const now = Date.now();
      const h = [{ t: now, text: 'Создана администратором' }]; if (pay !== 'awaiting') h.push({ t: now, text: pay === 'full' ? 'Оплачено полностью' : 'Предоплата получена' });
      const b = createBooking(o, { status: pay === 'awaiting' ? 'awaiting' : 'confirmed', source: 'admin', full_paid: pay === 'full', paid_at: now, confirmed_at: pay === 'awaiting' ? null : now, history: h });
      if (pay === 'awaiting') b.created_at = now;
      log('Администратор создал бронь ' + bLine(b) + ', ' + b.name);
      return send(res, 201, { booking: b });
    }
    mm = p.match(/^\/api\/admin\/bookings\/(\d+)\/action$/);
    if (m === 'POST' && mm) {
      const b = getB(+mm[1]); if (!b) throw httpErr(404, 'Бронь не найдена');
      const body = await readBody(req);
      applyAction(b, String(body.action || ''), body, 'админка');
      const out = getB(b.id); delete out.token; return send(res, 200, { booking: out });
    }
    if (m === 'PUT' && p === '/api/admin/settings') {
      const body = await readBody(req); const n = (v, min, max) => { v = +v; if (!isFinite(v)) throw httpErr(400, 'Проверьте числа в настройках'); return Math.max(min, Math.min(max, v)); };
      const s = body.settings || {}; const next = JSON.parse(JSON.stringify(S));
      if (s.pay) next.pay = { bank: String(s.pay.bank || '').slice(0, 100), card: String(s.pay.card || '').slice(0, 40), sbp: String(s.pay.sbp || '').slice(0, 40), holder: String(s.pay.holder || '').slice(0, 100) };
      ['payMin', 'confirmH'].forEach(k => { if (s[k] != null) next[k] = n(s[k], 1, 1000); });
      if (s.prepay != null) next.prepay = n(s.prepay, 0, 1);
      if (s.nightK != null) next.nightK = n(s.nightK, 1, 5);
      ['guestFree', 'guestFee', 'techFee', 'cycFee'].forEach(k => { if (s[k] != null) next[k] = n(s[k], 0, 1e6); });
      if (Array.isArray(s.halls)) s.halls.forEach(x => { const h = next.halls.find(y => y.id === x.id); if (h) { h.wd = n(x.wd, 0, 1e6); h.we = n(x.we, 0, 1e6); } });
      if (Array.isArray(s.eventTiers)) s.eventTiers.forEach((x, i) => { if (next.eventTiers[i]) { next.eventTiers[i].wd = n(x.wd, 0, 1e6); next.eventTiers[i].we = n(x.we, 0, 1e6); } });
      saveSettings(next); S = getSettings(); log('Настройки обновлены администратором');
      return send(res, 200, { settings: S });
    }
  }
  throw httpErr(404, 'Не найдено');
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, { error: 'Метод не поддерживается' });
    if (url.pathname === '/healthz') return send(res, 200, { ok: true });
    serveStatic(req, res, url.pathname);
  } catch (e) {
    if (!e.code || typeof e.code !== 'number') console.error(e);
    send(res, typeof e.code === 'number' ? e.code : 500, { error: typeof e.code === 'number' ? e.message : 'Ошибка сервера' });
  }
});

/* ---------- фоновые задачи: сроки, сводка, резервная копия ---------- */
let lastSummary = '', lastBackup = '';
function tick() {
  const now = Date.now();
  db.prepare("SELECT * FROM bookings WHERE status IN ('awaiting','review')").all().map(row2b).forEach(b => {
    if (b.status === 'awaiting' && b.source === 'online' && now > deadline(b)) {
      b.status = 'expired'; hist(b, 'Не оплачена за ' + S.payMin + ' минут'); saveB(b); log('Не оплачена вовремя, время освобождено: ' + bLine(b));
    } else if (b.status === 'review' && !b.overdue && now > deadline(b)) {
      b.overdue = true; saveB(b); log('Просрочено подтверждение: ' + bLine(b));
      notifyAdmins('⏰ <b>Прошло ' + S.confirmH + ' ч, бронь не подтверждена</b>\n' + bLine(b) + '\n' + escH(b.name) + ', ' + escH(b.phone) + '. Клиент ждёт ответа.', [[{ text: '✅ Деньги пришли', callback_data: 'c:' + b.id }, { text: '✗ Перевода нет', callback_data: 'r:' + b.id }]]);
    }
  });
  const d = new Date(), t = todayStr();
  if (d.getHours() === (S.summaryHour || 9) && lastSummary !== t) { lastSummary = t; notifyAdmins(todaySummary()); }
  if (d.getHours() === 3 && lastBackup !== t) {
    lastBackup = t;
    try {
      const f = path.join(DATA, 'backups', t + '.sqlite'); if (fs.existsSync(f)) fs.unlinkSync(f);
      db.exec("VACUUM INTO '" + f.replace(/'/g, "''") + "'");
      fs.readdirSync(path.join(DATA, 'backups')).filter(x => x.endsWith('.sqlite')).sort().slice(0, -14).forEach(x => fs.unlinkSync(path.join(DATA, 'backups', x)));
    } catch (e) { console.error('backup', e.message); }
  }
}
setInterval(tick, 20000); tick();
/* короткий keep-alive: промежуточные узлы сети обрывают простаивающие соединения, а браузер потом ждёт ~16 с на мёртвом */
server.keepAliveTimeout = 3000; server.headersTimeout = 10000;
server.listen(PORT, () => console.log('МЕДИАПОРТ бронь: ' + PUBLIC_URL + ' (порт ' + PORT + ')'));
botLoop();
